import os
import re
import uuid
import shutil
import json
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_from_directory, make_response
from werkzeug.utils import secure_filename

from docx import Document
from reportlab.lib.pagesizes import inch
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, PageBreak, CondPageBreak, Flowable, Image as RLImage, NextPageTemplate
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.colors import HexColor
from PyPDF2 import PdfReader, PdfWriter, PageObject, Transformation
from PIL import Image
# v49: familia Times registrada para que <b> de Paragraph use Times-Bold real
from reportlab.pdfbase.pdfmetrics import registerFontFamily as _rl_rff
_rl_rff('Times-Roman', normal='Times-Roman', bold='Times-Bold', italic='Times-Italic', boldItalic='Times-BoldItalic')

VERSION = 'v83'

app = Flask(__name__)
BASE_DIR = Path(__file__).parent
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "outputs"
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

ALLOWED_DOC = {'.docx','.doc','.txt'}
ALLOWED_IMG = {'.png','.jpg','.jpeg','.gif','.bmp','.webp'}

PAGE_W = 5.5 * inch
PAGE_H = 8.5 * inch
FOLLETO_W = 11 * inch
FOLLETO_H = 8.5 * inch

# v68 MARGENES NUEVAS (anotaciones del usuario sobre el folleto impreso):
# ARRIBA 2.0cm al cuerpo, ABAJO 1.9cm, EXTERIOR 1.9cm, INTERIOR 1.5cm.
# Centro del folleto = interior izq + interior der = 3.0cm (antes 3.15cm).
# Paginas IMPARES (recto, caen a la DERECHA en el folleto): izq 1.5 / der 1.9.
# Paginas PARES (verso, izquierda): izq 1.9 / der 1.5. La PORTADA queda
# CONGELADA a la geometria v66 (0.62/0.65in) -> ver frame_cover.
DEFAULT_MARGINS = {
    'top': 2.0 / 2.54,     # 2.0 cm = 56.69pt (medido al CUERPO; el encabezado queda mas arriba)
    'bottom': 1.9 / 2.54,  # 1.9 cm = 53.86pt
    'inner': 1.5 / 2.54,   # 1.5 cm = 42.52pt (centro folleto = 3.0cm)
    'outer': 1.9 / 2.54    # 1.9 cm = 53.86pt (exterior folleto)
}

# v68b calibracion de TINTA (medido con pymupdf, Times 13pt/leading 16.5, padding 0):
# la 1ra linea de texto queda ~0.64pt por DEBAJO del borde superior del frame y
# la ultima linea de una pagina llena queda ~5.3pt por ENCIMA del borde inferior.
# Con estos lags la TINTA (lo que mide el usuario con regla) cae exactamente en
# los cm de DEFAULT_MARGINS: cuerpo arriba 2.00cm, abajo 1.90cm.
_M_INK_TOP_LAG = 0.64
_M_INK_BOT_LAG = 5.3

# ------------------ PARSERS ------------------

def is_author_line(line):
    l = line.lower()
    return any(k in l for k in ['william soto','soto santiago','branham','dr.','rev.','william marrion'])

def is_date_line(line):
    days = ['domingo','lunes','martes','miércoles','miercoles','jueves','viernes','sábado','sabado']
    months = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre']
    l = line.lower()
    has_day = any(d in l for d in days)
    has_month = any(m in l for m in months)
    has_year = bool(re.search(r'\b(19|20)\d{2}\b', line))
    return (has_day or has_month) and has_year

def is_city_line(line):
    # short, contains comma or known places, not too long
    # Also handle case where city + body are on same line: "San Pablo, Brasil “Entonces..."
    # We check if line starts with city pattern
    if len(line) > 150:
        # Might be city + body combined, check first 80 chars
        first_part = line[:80]
        if ',' in first_part:
            places = ['puerto rico','cayey','chile','santiago','argentina','buenos aires','brasil','bolivia','la paz','colombia','cartagena','ponce','san pablo']
            if any(p in first_part.lower() for p in places):
                return True
        return False
    if ',' in line and len(line) < 80:
        return True
    places = ['puerto rico','cayey','chile','santiago','argentina','buenos aires','brasil','bolivia','la paz','colombia','cartagena','ponce','san pablo']
    l = line.lower()
    return any(p in l for p in places)

def extract_city_and_body(line):
    """If line contains city + body together, split it"""
    # Known city patterns
    city_patterns = [
        r'^(.*?(?:Puerto Rico|Cayey|Chile|Santiago|Argentina|Buenos Aires|Brasil|Bolivia|La Paz|Colombia|Cartagena|Ponce|San Pablo.*?Brasil).*?)(?:\s+[“"A-Z].*)?$',
    ]
    # Try to find city at beginning
    # Look for pattern: city is up to first occurrence of " or “ or capital letter starting body
    # Simpler: if line contains a city and then has a quote or long text, split at city end
    places = ['Cayey, Puerto Rico','Santiago de Chile, Chile','Buenos Aires, Argentina','San Pablo, Brasil','La Paz, Bolivia','Cartagena, Colombia','Cayey, Puerto Rico','Ponce, Puerto Rico']
    for place in places:
        if place.lower() in line.lower():
            idx = line.lower().find(place.lower()) + len(place)
            city = line[:idx].strip()
            rest = line[idx:].strip()
            # If rest is body (starts with quote or long)
            if rest and len(rest) > 10:
                return city, rest
    # Fallback: split by comma + city, then rest
    # If line has comma and then a quote
    if '“' in line or '"' in line:
        # Find last comma before quote
        quote_idx = line.find('“')
        if quote_idx == -1:
            quote_idx = line.find('"')
        if quote_idx > 0:
            # Check if before quote there's a city-like short segment
            before = line[:quote_idx]
            # If before contains comma and is <60 chars after last period
            # Take last 60 chars before quote as potential city
            potential_city = before[-60:].strip()
            # If potential city contains comma and known place
            if ',' in potential_city and any(p in potential_city.lower() for p in ['puerto rico','chile','argentina','brasil','bolivia','colombia']):
                # Extract city as that potential_city
                # Find where city starts
                city_start = before.rfind(potential_city)
                city = potential_city
                rest = line[quote_idx:].strip()
                return city, rest
    return line, None

def is_title_line(line):
    if not line:
        return False
    if len(line) > 120:
        return False
    if is_author_line(line) or is_date_line(line) or is_city_line(line):
        return False
    if line.startswith('(') and line.endswith(')'):
        return False
    # Title is mostly uppercase or title case but short
    # Check if uppercase ratio high
    letters = [c for c in line if c.isalpha()]
    if not letters:
        return False
    upper = sum(1 for c in letters if c.isupper())
    ratio = upper / len(letters) if letters else 0
    # Title usually >0.7 uppercase
    return ratio > 0.7 and len(line) >= 3

def _ancla_titulo(lines, paras, i, k):
    """v81: devuelve el indice donde EMPIEZA el titulo real, caminando hacia
    atras desde el bloque de autor (k-1). Las lineas MAYUSCULAS del CUERPO
    del extracto anterior (las que terminan en punto/.!?...) ya no se cuelan
    como titulo: el titulo real empieza en la linea candidata que arranca
    parrafo (linea vacia o punto arriba)."""
    j = k - 1
    cand = []
    while j >= i and len(cand) < 3:
        l = lines[j]
        if not is_title_line(l):
            break
        if re.search(r'[.!?…]["»\)\]]*\s*$', l):
            break
        cand.append(j)
        j -= 1
    if not cand:
        return None
    for idx in sorted(cand):
        if paras[idx]:
            return idx
    return cand[-1]

def parse_txt_advanced(txt_path):
    """Parse the raw txt into extracts"""
    with open(txt_path, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    # Normalize line endings
    content = content.replace('\r\n','\n').replace('\r','\n')
    lines = [l.strip() for l in content.split('\n')]
    # v50: recordar que linea inicia PARRAFO real (la linea anterior estaba en blanco).
    # Los saltos simples son cortes de linea (wrap); el separador de parrafo = linea vacia.
    tagged = []
    _prev_blank = False
    _prev_finde_frase = False
    _forzados = set()
    _force_next = False
    for _l in lines:
        if _l.strip() == '':
            _prev_blank = True
            _prev_finde_frase = False
            continue
        # v81: comando ---T--- en el TEXTO = la linea siguiente es TITULO
        # seguro (el usuario fuerza donde empieza un extracto).
        if _l.strip() in ('---T---', '---t---'):
            _force_next = True
            _prev_blank = False
            _prev_finde_frase = False
            continue
        if _force_next:
            _forzados.add(len(tagged))
            _force_next = False
        # v52: un salto de linea DONDE la linea anterior termina en punto/.!? (o
        # cierra comilla/parentesis despues) = PARRAFO nuevo. Los cortes a mitad
        # de frase (linea que no termina en puntuacion) son continuacion normal.
        tagged.append((_l, _prev_blank, _prev_finde_frase))
        _prev_blank = False
        _prev_finde_frase = bool(re.search(r'[.!?…]["»\)\]]*\s*$', _l))
    non_empty = [t[0] for t in tagged]
    para_starts = [(t[1] or t[2]) for t in tagged]
    if not non_empty:
        return [], "TITULO"

    book_title = non_empty[0]
    # If second line looks like title of extract, book title is first line
    # Remove book title from processing if it is overall title
    # Heuristic: if first line is all caps and length >10 and second line is also all caps and followed by author
    extracts = []
    i = 1  # start after book title
    # If first line is actually an extract title (no book title), adjust
    if is_author_line(non_empty[1]) or non_empty[1].startswith('('):
        # Then first line is actually first extract title, not book title
        book_title = "EL TÍTULO DE PROPIEDAD EN LA TIERRA"
        i = 0
    else:
        # Check if first line is book title, keep it
        pass

    while i < len(non_empty):
        line = non_empty[i]
        # Detect start of new extract: title line
        if not is_title_line(line) and i not in _forzados:
            # If not title, maybe it's continuation of previous body? Should not happen at start
            i+=1
            continue

        # Collect title lines (1-3 consecutive title lines)
        title_lines = []
        while i < len(non_empty) and (is_title_line(non_empty[i]) or i in _forzados) and len(title_lines) < 3:
            # Peek next: if next is author or subtitle, stop collecting title after 1-2 lines
            # But allow multi-line title
            title_lines.append(non_empty[i])
            i+=1
            # Look ahead: if next line is subtitle or author, break
            if i < len(non_empty):
                nxt = non_empty[i]
                if nxt.startswith('(') or is_author_line(nxt):
                    break
                # If next is not title (lowercase), break
                if not is_title_line(nxt):
                    # Could still be title if short and upper, continue
                    if len(nxt) < 5:
                        break
                    # If next is long sentence (body), break
                    if len(nxt) > 120:
                        break
        # Subtitle optional
        subtitle = None
        if i < len(non_empty) and non_empty[i].startswith('('):
            subtitle = non_empty[i]
            i+=1

        # Author
        author = ""
        if i < len(non_empty) and is_author_line(non_empty[i]):
            author = non_empty[i]
            i+=1

        # Date
        date = ""
        if i < len(non_empty) and is_date_line(non_empty[i]):
            date = non_empty[i]
            i+=1

        # City (handle city+body on same line)
        city = ""
        if i < len(non_empty) and is_city_line(non_empty[i]):
            city_line = non_empty[i]
            city_extracted, body_remainder = extract_city_and_body(city_line)
            # If extract_city_and_body returned split
            if body_remainder:
                city = city_extracted
                # Insert body remainder as first body part
                # We'll handle by inserting into body_parts later
                i+=1
                # Store remainder to be added to body
                # Use a temporary variable
                pending_body = body_remainder
            else:
                city = city_line
                pending_body = None
                i+=1
        else:
            pending_body = None

        # Body: collect until next extract start
        body_parts = []
        body_seps = []
        if 'pending_body' in locals() and pending_body:
            body_parts.append(pending_body)
            body_seps.append('')
        while i < len(non_empty):
            # Peek if next lines form new extract
            # New extract pattern: title line + (subtitle or author)
            if is_title_line(non_empty[i]) or i in _forzados:
                # v81: se busca el ancla (autor/subtitulo/fecha) y se CAMINA
                # hacia atras hasta el titulo real. Las lineas MAYUSCULAS del
                # cuerpo anterior que terminan en punto ya NO se cuelan como
                # titulo (ese era el fallo de los "titulos falsos").
                _k = None
                for _off, _l in enumerate(non_empty[i+1:i+4]):
                    if is_author_line(_l) or _l.startswith('(') or is_date_line(_l):
                        _k = i + 1 + _off
                        break
                if _k is not None or i in _forzados:
                    _t = None
                    if _k is not None:
                        # v81: si hay un ---T--- del usuario en la ventana, el
                        # forzado MANDA (el titulo empieza donde el usuario dijo).
                        _f9 = [j for j in range(i + 1, _k + 1) if j in _forzados]
                        if _f9:
                            _t = _f9[0]
                    if _t is None:
                        if i in _forzados:
                            _t = i
                        elif _k is not None:
                            _t2 = _ancla_titulo(non_empty, para_starts, i, _k)
                            _t = _t2 if _t2 is not None else i
                    # las lineas salteadas eran CUERPO del extracto actual
                    while i < _t:
                        body_parts.append(non_empty[i])
                        body_seps.append('\n\n' if para_starts[i] else ' ')
                        i += 1
                    break
            body_parts.append(non_empty[i])
            body_seps.append('\n\n' if para_starts[i] else ' ')
            i+=1

        body = "".join(sep + part for sep, part in zip(body_seps, body_parts)).strip()
        if body or title_lines:
            extracts.append({
                'title_lines': title_lines,
                'subtitle': subtitle,
                'author': author,
                'date': date,
                'city': city,
                'body': body
            })

    # v82: ---/// al FINAL de un extracto (justo antes del titulo siguiente)
    # = renglones extra ANTES de ese titulo. Se sacan del cuerpo y viajan con
    # el titulo: le dan aire y, si no caben, el titulo pasa ENTERO a la otra
    # pagina (nunca queda varado). Maximo 5 para proteger el ajuste.
    for _ei, _e in enumerate(extracts):
        _n = 0
        while _e['body']:
            _mm = re.search(r'(?:\n\s*)?((?:---///\s*)+)$', _e['body'])
            if not _mm:
                break
            _n += len(re.findall(r'---///', _mm.group(1)))
            _e['body'] = _e['body'][:_mm.start()].rstrip()
        if _n and _ei + 1 < len(extracts):
            extracts[_ei + 1]['pre_lines'] = min(5, _n)

    return extracts, book_title

def parse_docx_advanced(docx_path):
    """Parse docx into extracts similar structure, fallback to simple paragraphs"""
    doc = Document(docx_path)
    # Extract text lines
    full_text = "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
    # Save temp txt and reuse parser
    tmp_txt = str(UPLOAD_DIR / f"tmp_{uuid.uuid4().hex}.txt")
    with open(tmp_txt, 'w', encoding='utf-8') as f:
        f.write(full_text)
    extracts, book_title = parse_txt_advanced(tmp_txt)
    os.remove(tmp_txt)
    # If parser fails to find extracts, fallback to paragraphs
    if not extracts:
        paragraphs = []
        for para in doc.paragraphs:
            txt = para.text.strip()
            if not txt:
                continue
            paragraphs.append(txt)
        # Create single extract
        return [{'title_lines':[], 'subtitle':None,'author':'','date':'','city':'','body':"\n\n".join(paragraphs)}], book_title
    return extracts, book_title

def parse_any_file(file_path):
    ext = Path(file_path).suffix.lower()
    if ext == '.txt':
        return parse_txt_advanced(file_path)
    else:
        return parse_docx_advanced(file_path)

# ------------------ PDF GENERATION ------------------

def escape_text(t):
    return t.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

def _auto_bold_core(body_text):
    """Nucleo original validado: frases mayormente MAYUSCULAS -> <b>.
    Se mantiene EXACTO al comportamiento desde v42 (sin marcadores)."""
    sentences = re.split(r'(?<=[.!?])\s+', body_text)
    formatted = []
    for sent in sentences:
        if not sent.strip():
            continue
        letters = [c for c in sent if c.isalpha()]
        if len(letters) > 15:
            upper = sum(1 for c in letters if c.isupper())
            ratio = upper / len(letters)
            if ratio > 0.85 and len(sent.strip()) > 20:
                formatted.append(f"<b>{escape_text(sent.strip())}</b>")
                continue
        formatted.append(escape_text(sent.strip()))
    return " ".join(formatted)

def _piece_with_ws(piece):
    """Aplica el nucleo conservando los espacios de los bordes del trozo."""
    lead = piece[:len(piece) - len(piece.lstrip())]
    trail = piece[len(piece.rstrip()):]
    core = _auto_bold_core(piece.strip())
    if not core:
        return lead + trail
    return lead + core + trail

def _strip_markers(t):
    return t.replace('[[B]]', '').replace('[[/B]]', '')

def format_body_with_bold(body_text):
    """Convierte el cuerpo a Paragraph de ReportLab con <b>:
    1) frases mayormente MAYUSCULAS (negrita automatica de siempre), y
    2) NUEVO v49: negrita exacta con marcadores [[B]]...[[/B]] (los mismos
       del Editor Manual); se ven en el PDF respetando May/min del usuario.
       Marcadores sin pareja se limpian (nunca se imprimen literalmente)."""
    if not body_text:
        return ""
    if '[[B]]' not in body_text and '[[/B]]' not in body_text:
        return _auto_bold_core(body_text)
    out = []
    pos = 0
    for m in re.finditer(r'\[\[B\]\](.*?)\[\[/B\]\]', body_text, re.S):
        pre = _strip_markers(body_text[pos:m.start()])
        if pre:
            out.append(_piece_with_ws(pre))
        out.append(f"<b>{escape_text(m.group(1))}</b>")
        pos = m.end()
    tail = _strip_markers(body_text[pos:])
    if tail:
        out.append(_piece_with_ws(tail))
    return "".join(out)

# v55: POLITICA DE TITULOS AL FINAL DE PAGINA (3 niveles) -------------------
# El titulo NUNCA queda solo al final de una pagina y el espacio SIEMPRE
# se aprovecha al maximo, en 3 niveles:
#   1) Cabe titulo + renglon + 1 linea del texto  -> SE QUEDA normal.
#   2) No cabe el renglon pero SI titulo + 1 linea pegada -> SE QUEDA
#      APRETADO: la primera linea del texto queda justo debajo del bloque,
#      sin el renglon adicional (asi no hay hueco en blanco al final).
#   3) No cabe ni eso -> el titulo pasa ENTERO a la pagina siguiente,
#      ahi SIEMPRE conserva su renglon normal y el texto empieza con
#      sangria, como en cualquier pagina.
# (FitTitulo decide el nivel midiendo el espacio disponible del marco.)
import threading as _threading_tl
_TL = _threading_tl.local()

class FitTitulo(CondPageBreak):
    """Decide el nivel: normal (cabe con renglon), tight (cabe apretado
    sin renglon) o pagina nueva (no cabe ni apretado)."""
    def __init__(self, full_h, tight_h):
        CondPageBreak.__init__(self, full_h)
        self._tight_h = tight_h
    def wrap(self, availWidth, availHeight):
        if availHeight >= self.height:
            _TL.modo = 'normal'
            return (0, 0)
        if availHeight >= self._tight_h:
            _TL.modo = 'tight'
            return (0, 0)
        _TL.modo = 'nuevo'
        return CondPageBreak.wrap(self, availWidth, availHeight)

class AjustaTitulo(Flowable):
    """Aplica el estilo comprimido al bloque del titulo SOLO en modo apretado
    (tight): sin renglon antes del titulo y con interlineado interno reducido.
    En modo normal o pagina nueva deja los estilos originales."""
    def __init__(self, pares):
        Flowable.__init__(self)
        self._pares = pares  # [(paragraph, estilo_apretado, estilo_normal), ...]
    def wrap(self, availWidth, availHeight):
        modo = getattr(_TL, 'modo', 'normal')
        for _p, _ts, _orig in self._pares:
            _p.style = _ts if modo == 'tight' else _orig
        return (0, 0)
    def draw(self):
        pass  # flowable invisible: solo ajusta estilos

class GapTitulo(Spacer):
    """Renglon despues del titulo: se suprime SOLO en modo apretado (tight);
    en titulo a mitad de pagina y en titulo movido a pagina nueva se conserva."""
    def __init__(self, h):
        Spacer.__init__(self, 0, h)
    def wrap(self, availWidth, availHeight):
        if getattr(_TL, 'modo', 'normal') == 'tight':
            _TL.modo = 'normal'
            return (0, 0)
        return (0, self.height)

# v58: RENGLON (interlineado) DEL CUERPO POR EXTRACTO -----------------------
def _match_extract_idx(extracts, titulo):
    """Indice del extracto cuyo 1er titulo coincide con el ajuste (misma regla v57)."""
    _at = (titulo or '').strip().upper()
    if not _at:
        return None
    for _i, _e in enumerate(extracts):
        _tl0 = ((_e.get('title_lines') or [''])[0] or '').strip().upper()
        if _tl0 and (_tl0.startswith(_at[:24]) or _at.startswith(_tl0[:24])):
            return _i
    return None

def _pdf_num_pages(pdf_path):
    try:
        from PyPDF2 import PdfReader
        return len(PdfReader(pdf_path).pages)
    except Exception:
        return 0

def _extract_end_gap(pdf_path, extracts, idx):
    """(gap_pt, n_lineas) en la ULTIMA pagina del extracto idx.
    Busqueda acotada: entre la pagina del titulo del extracto y la del
    titulo siguiente (asi una frase repetida en otro extracto no confunde).
    gap = 556.0 - y1 mas bajo del texto de esa pagina."""
    try:
        import pymupdf as _pm
    except Exception:
        return None, None
    try:
        ext = extracts[idx]
        _fr = ' '.join(_strip_markers(ext.get('body') or '').split()).upper()[-70:]
        if len(_fr) < 15:
            return None, None
        def _t0_de(e):
            return ((e.get('title_lines') or [''])[0] or '').strip().upper()[:24]
        doc = _pm.open(pdf_path)
        _norm = [' '.join(doc[_i].get_text().upper().split()) for _i in range(len(doc))]
        _t0 = _t0_de(ext)
        _t_ini = 2
        if _t0:
            for _i in range(2, len(doc)):
                if _t0 in _norm[_i]:
                    _t_ini = _i
                    break
        _t_fin = len(doc) - 1
        if idx + 1 < len(extracts):
            _tn = _t0_de(extracts[idx + 1])
            if _tn:
                for _i in range(_t_ini, len(doc)):
                    if _tn in _norm[_i]:
                        _t_fin = _i
                        break
        _pgi = None
        for _i in range(_t_fin, _t_ini - 1, -1):
            if _fr in _norm[_i]:
                _pgi = _i
                break
        if _pgi is None:
            _pgi = _t_ini
        _ys = []
        _y0s = set()
        for b in doc[_pgi].get_text('dict')['blocks']:
            for l in b.get('lines', []):
                for s in l['spans']:
                    if s['text'].strip() and s['bbox'][1] > 45:
                        _ys.append(s['bbox'][3])
                        _y0s.add(round(s['bbox'][1]))
        doc.close()
        if not _ys:
            return None, None
        return round(556.0 - max(_ys), 1), len(_y0s)
    except Exception:
        return None, None

def create_digital_pdf(extracts, title, logo_path, output_path, margins, start_page=164, title_gap=18, ajustes=None):
    # Versión exacta igual a referencia 7.Dig.EL TÍTULO...pdf (17 págs: portada+blanco+15 contenido)
    # Ajuste fino imagen 1 y 2: extra_bottom 12 mantiene 17p, header_y +2 reduce espacio inicio a mitad (8pt en vez de 16pt)
    # title_gap: renglón antes de títulos (puntos). AJUSTABLE, mínimo 1 renglón = 18pt (nunca más pequeño)
    # ajustes (v57): ordenes manuales del Ajustador de paginas [{titulo, modo, renglon_pt}]
    _ajs = list(ajustes) if ajustes else []
    _lls = [a for a in _ajs if (a.get('modo') == 'llenar')]
    if not _lls:
        return _create_digital_pdf_once(extracts, title, logo_path, output_path, margins, start_page, extra_bottom=12, title_gap=title_gap, ajustes=_ajs)
    # v58 modo 'llenar': prueba el interlineado del extracto hasta que su ultima
    # pagina quede llena (sin agregar paginas). Nunca toca los demas extractos.
    import os as _os, shutil as _sh
    _tmps = []
    def _build(ajs_, out_):
        return _create_digital_pdf_once(extracts, title, logo_path, out_, margins, start_page, extra_bottom=12, title_gap=title_gap, ajustes=ajs_)
    def _nuevo_tmp():
        _t = _os.path.join('/tmp' if _os.path.isdir('/tmp') else '.', 'llenar_%s.pdf' % _os.urandom(4).hex())
        _tmps.append(_t)
        return _t
    _actual = _build(_ajs, _nuevo_tmp())
    for _a0 in _lls:
        _i0 = _match_extract_idx(extracts, _a0.get('titulo'))
        if _i0 is None:
            continue
        _g, _n = _extract_end_gap(_actual, extracts, _i0)
        if _g is None or _g < 12 or not _n:
            continue
        _pag_base = _pdf_num_pages(_actual)
        _Lcur = 16.5
        for _ in range(3):
            _inc = min(8.0, _g / float(_n))
            _Ltry = min(26.0, _Lcur + _inc)
            if _Ltry <= _Lcur + 0.2:
                break
            _a2 = dict(_a0); _a2['_llenar_L'] = round(_Ltry, 2)
            _ajs2 = [_a2 if (x is _a0) else x for x in _ajs]
            _t2 = _build(_ajs2, _nuevo_tmp())
            _g2, _n2 = _extract_end_gap(_t2, extracts, _i0)
            _p2 = _pdf_num_pages(_t2)
            if _g2 is None or _p2 > _pag_base or _g2 >= _g:
                # se paso de largo (o no mejoro): prueba la MITAD del incremento
                _Lhalf = _Lcur + (_Ltry - _Lcur) / 2.0
                _a3 = dict(_a0); _a3['_llenar_L'] = round(_Lhalf, 2)
                _ajs3 = [_a3 if (x is _a0) else x for x in _ajs]
                _t3 = _build(_ajs3, _nuevo_tmp())
                _g3, _n3 = _extract_end_gap(_t3, extracts, _i0)
                _p3 = _pdf_num_pages(_t3)
                if _g3 is not None and _p3 <= _pag_base and _g3 < _g:
                    _actual, _g, _n, _Lcur = _t3, _g3, _n3, _Lhalf
                break
            _actual, _g, _n, _Lcur = _t2, _g2, _n2, _Ltry
            if _g2 < 12:
                break
        # v75 FIX: CONSERVAR el llenado resuelto de este extracto para que los
        # siguientes ajustes 'llenar' (NIVELAR) no lo borren al reconstruir.
        _a0['_llenar_L'] = round(_Lcur, 2)
    for _t in _tmps:
        if _t != _actual:
            try:
                _os.remove(_t)
            except Exception:
                pass
    _sh.copyfile(_actual, output_path)
    for _t in _tmps:
        try:
            _os.remove(_t)
        except Exception:
            pass
    return output_path

def _create_digital_pdf_once(extracts, title, logo_path, output_path, margins, start_page, extra_bottom, title_gap=18, ajustes=None):
    m_top = margins.get('top', DEFAULT_MARGINS['top']) * inch
    m_bottom = margins.get('bottom', DEFAULT_MARGINS['bottom']) * inch
    m_inner = margins.get('inner', DEFAULT_MARGINS['inner']) * inch
    m_outer = margins.get('outer', DEFAULT_MARGINS['outer']) * inch

    # Estilos igual a referencia 17p: leading 16.5 da 17 páginas (15.0=15p, 16.0=16p, 16.5=17p) + extra_bottom 6 para espacio mitad al inicio (imagen 2)
    # Ajuste fino imagen 1: si empieza página con título, no dar espacio extra (spaceBefore=0)
    style_body = ParagraphStyle(
        'body',
        fontName='Times-Roman',
        fontSize=13,
        leading=16.5,
        alignment=TA_JUSTIFY,
        spaceAfter=0,
        spaceBefore=0,
        firstLineIndent=22,
        allowOrphans=1,  # v54: permite dejar 1 linea bajo el titulo al final de pagina
    )
    style_body_first = ParagraphStyle(
        'body_first',
        fontName='Times-Roman',
        fontSize=13,
        leading=16.5,
        alignment=TA_JUSTIFY,
        spaceAfter=0,
        spaceBefore=0,
        firstLineIndent=22,  # v50: sangria TAMBIEN en el 1er parrafo (como la referencia Word)
        allowOrphans=1,  # v54: permite dejar 1 linea bajo el titulo al final de pagina
    )
    style_title = ParagraphStyle(
        'title_block',
        fontName='Times-Bold',
        fontSize=13,
        leading=14,
        alignment=TA_CENTER,
        spaceBefore=0,
        spaceAfter=2,
    )
    # Gap de un renglón ANTES de cada título (18pt = referencia 7.Dig / v21), SOLO en la 1ra
    # línea del título. El Spacer del fin de extracto se ELIMINÓ: si caía a inicio de página
    # desactivaba _atTop y el spaceBefore ya no se omitía (imagen 1).
    # Reportlab omite spaceBefore cuando el título cae a inicio de página -> 0 extra siempre.
    style_title_first = ParagraphStyle(
        'title_block_first',
        fontName='Times-Bold',
        fontSize=13,
        leading=14,
        alignment=TA_CENTER,
        spaceBefore=18,
        spaceAfter=2,
    )
    # Renglón antes de títulos AJUSTABLE: mínimo 1 renglón (18pt), puede ser más grande
    style_title_first.spaceBefore = max(18.0, float(title_gap))
    style_subtitle = ParagraphStyle(
        'subtitle',
        fontName='Times-Italic',
        fontSize=13,
        leading=14,
        alignment=TA_CENTER,
        spaceAfter=2,
        spaceBefore=0,
    )
    style_author = ParagraphStyle(
        'author',
        fontName='Times-Italic',
        fontSize=13,
        leading=14,
        alignment=TA_CENTER,
        spaceAfter=0,
        spaceBefore=0,
    )
    style_date = ParagraphStyle(
        'date',
        fontName='Times-Italic',
        fontSize=13,
        leading=14,
        alignment=TA_CENTER,
        spaceAfter=0,
        spaceBefore=0,
    )
    style_city = ParagraphStyle(
        'city',
        fontName='Times-Italic',
        fontSize=13,
        leading=14,
        alignment=TA_CENTER,
        spaceAfter=4,  # antes 8 -> mitad
        spaceBefore=0,
    )
    # v66: portada IGUAL a la referencia (7.Dig): etiqueta Times-Bold 18pt
    # ALINEADA A LA IZQUIERDA en el margen, titulo 24pt/28 centrado
    style_cover_sub = ParagraphStyle(
        'cover_sub',
        fontName='Times-Bold',
        fontSize=18,
        leading=20,
        alignment=TA_LEFT,
        spaceAfter=12,
    )
    style_cover_title = ParagraphStyle(
        'cover_title',
        fontName='Times-Bold',
        fontSize=24,
        leading=28,
        alignment=TA_CENTER,
        spaceAfter=24,
    )

    def header_footer(canvas, doc):
        canvas.saveState()
        page_num = doc.page
        if page_num <= 2:
            canvas.restoreState()
            return
        if page_num == 3:
            canvas.restoreState()
            return
        # Página 4 en adelante con numeración exacta como referencia: pág 4 = start_page (164 par izquierda, 165 impar derecha)
        effective_start = start_page
        display_num = effective_start + (page_num - 4)
        is_odd = (page_num % 2 == 1)

        # Header Y - v68b: el cuerpo (TINTA) empieza EXACTO en m_top (2.0cm);
        # frame top = PAGE_H - m_top + _M_INK_TOP_LAG y la linea divisoria queda
        # a 8pt sobre la tinta (mismo gap visual aprobado), baseline 6pt sobre linea.
        header_y = PAGE_H - m_top + _M_INK_TOP_LAG + 14

        # Línea divisoria debajo del header - como en imagen 2
        line_y = header_y - 6
        canvas.setStrokeColor(HexColor('#000000'))
        canvas.setLineWidth(0.6)
        # v68: linea del ancho del bloque de texto ESPEJADO (paridad real)
        if is_odd:
            canvas.line(m_inner, line_y, PAGE_W - m_outer, line_y)
        else:
            canvas.line(m_outer, line_y, PAGE_W - m_inner, line_y)

        # Fuente del encabezado igual que título - 11pt Bold como en tu ejemplo original (medido 13pt, usamos 11pt para balance)
        canvas.setFont('Times-Bold', 11)
        canvas.setFillColor(HexColor('#000000'))

        if is_odd:
            # Título del libro y número - mismo tamaño
            canvas.drawString(m_inner, header_y, title[:55])
            canvas.drawRightString(PAGE_W - m_outer, header_y, str(display_num))
        else:
            # Número y "Extractos para Estudio:" - MISMO tamaño que título
            canvas.drawString(m_outer, header_y, str(display_num))
            canvas.drawRightString(PAGE_W - m_inner, header_y, "Extractos para Estudio:")

        canvas.restoreState()

    def cover_page(canvas, doc):
        canvas.saveState()
        canvas.restoreState()

    frame_width = PAGE_W - m_inner - m_outer
    # v68b: frames con padding 0 (la tinta toca EXACTO el margen: 1.5/1.9/3.0cm)
    # y altura calibrada para que la tinta caiga en 2.0cm arriba / 1.9cm abajo.
    _top_fb = PAGE_H - m_top + _M_INK_TOP_LAG      # borde sup del frame (desde abajo)
    _y1_fb = m_bottom - _M_INK_BOT_LAG             # borde inf del frame (desde abajo)
    frame_height = _top_fb - _y1_fb

    # v68 MARGENES ESPEJADAS libro real: template 'odd' se usa en pags IMPARES
    # 1-based (recto -> cae a la DERECHA del folleto): lomo a la izq -> x=m_inner.
    # template 'even' en pags PARES (verso -> izquierda): x=m_outer.
    _fargs = dict(leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    frame_odd = Frame(m_inner, _y1_fb, frame_width, frame_height, id='odd', **_fargs)
    frame_even = Frame(m_outer, _y1_fb, frame_width, frame_height, id='even', **_fargs)
    # v68: PORTADA CONGELADA a la geometria v66 aprobada (label 44.6/94.6,
    # titulo 112.6/258.8, Δ<=0.4pt vs referencia 7.Dig): usa 0.62/0.65in FIJOS.
    frame_cover = Frame(0.62*inch, 0.65*inch, PAGE_W - 1.24*inch, PAGE_H - 1.30*inch, id='cover', leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    frame_blank = Frame(m_outer, _y1_fb, frame_width, frame_height, id='blank', **_fargs)

    template_odd = PageTemplate(id='odd', frames=[frame_odd], onPage=header_footer, pagesize=(PAGE_W, PAGE_H))
    template_even = PageTemplate(id='even', frames=[frame_even], onPage=header_footer, pagesize=(PAGE_W, PAGE_H))
    template_odd.nextPageTemplate = 'even'
    template_even.nextPageTemplate = 'odd'
    template_cover = PageTemplate(id='cover', frames=[frame_cover], onPage=cover_page, pagesize=(PAGE_W, PAGE_H))
    template_blank = PageTemplate(id='blank', frames=[frame_blank], onPage=cover_page, pagesize=(PAGE_W, PAGE_H))

    from reportlab.platypus import KeepTogether

    doc_template = BaseDocTemplate(
        output_path,
        pagesize=(PAGE_W, PAGE_H),
        leftMargin=m_outer,
        rightMargin=m_outer,
        topMargin=m_top,
        bottomMargin=m_bottom,
        showBoundary=0
    )

    story = []
    story.append(NextPageTemplate('cover'))
    story.append(Spacer(1, 0.675*inch))  # v66: etiqueta inicia a y~94.6 como la referencia
    story.append(Paragraph("Extractos para Estudio:", style_cover_sub))
    story.append(Spacer(1, 1.84*inch))  # v66: titulo inicia a y~259 como la referencia
    cover_title_html = "<br/>".join([escape_text(t) for t in title.split('\n')]) if '\n' in title else escape_text(title.upper())
    story.append(Paragraph(cover_title_html, style_cover_title))
    story.append(Spacer(1, 0.25*inch))

    if logo_path and os.path.exists(logo_path):
        try:
            img = Image.open(logo_path)
            w,h = img.size
            # Limites máximos para que logo no se salga (tu corazón grande se salía)
            max_w = 2.2*inch
            max_h = 2.2*inch
            if w > 0 and h > 0:
                aspect = h / w if w else 1
                test_h = max_w * aspect
                if test_h <= max_h:
                    new_w = max_w
                    new_h = test_h
                else:
                    new_h = max_h
                    new_w = max_h / aspect if aspect else max_w
                # Si imagen pequeña, no ampliar demasiado
                if w < 300 and h < 300:
                    new_w = min(w * 0.9, max_w)
                    new_h = new_w * aspect
            else:
                new_w = max_w
                new_h = max_w
            rl_img = RLImage(logo_path, width=new_w, height=new_h)
            rl_img.hAlign = 'CENTER'
            story.append(rl_img)
            story.append(Spacer(1, 0.15*inch))
        except Exception as e:
            print(f"Logo error {e}")

    story.append(PageBreak())
    story.append(NextPageTemplate('blank'))
    story.append(Spacer(1,1))
    # v68b: el CICLO se registra ANTES del salto para que la pag 3 ya use 'odd'.
    # ReportLab lee ciclos (_nextPageTemplateCycle en handle_pageBegin) pero NO
    # el atributo .nextPageTemplate de los PageTemplate (eso era decorativo).
    story.append(NextPageTemplate(['odd', 'even']))
    story.append(PageBreak())

    if not extracts:
        story.append(Paragraph("Sin contenido", style_body))
    else:
        # v60: REGLAS 1 y 2 -> cambian el interlineado del extracto ANTERIOR
        # (el que termina en la pagina del titulo elegido)
        _prev_L = {}
        for _a in (ajustes or []):
            _m0 = _a.get('modo')
            if _m0 in ('regla1', 'regla2', 'regla10', 'regla11', 'regla12'):
                _i = _match_extract_idx(extracts, _a.get('titulo'))
                if _i is None or _i == 0:
                    continue
                try:
                    _vL = float(_a.get('renglon_pt') or 0)
                except Exception:
                    _vL = 0.0
                if not _vL:
                    _vL = 17.0 if _m0 == 'regla1' else 15.9  # 0.60 / 0.56 cm
                # v67 REGLA 12: ademas reduce la LETRA del extracto a 12.5pt
                _prev_L[_i - 1] = {'L': min(30.0, max(12.0, _vL)), 'F': (12.5 if _m0 == 'regla12' else None)}

        for ext_idx, ext in enumerate(extracts):
            _extr_L = None  # v58: interlineado del cuerpo (None = 16.5 normal)
            # Título como un solo bloque centrado para evitar huecos
            title_html_parts = []
            for tl in ext['title_lines']:
                if tl.strip():
                    title_html_parts.append(escape_text(tl.upper()))
            if ext['subtitle']:
                title_html_parts.append(escape_text(ext['subtitle']))
            if ext['author']:
                title_html_parts.append(escape_text(ext['author']))
            if ext['date']:
                title_html_parts.append(escape_text(ext['date']))
            if ext['city']:
                title_html_parts.append(escape_text(ext['city']))
            
            if title_html_parts:
                # Título bloque junto para que no se corte ciudad sola en otra página
                from reportlab.platypus import KeepTogether
                title_flow = []
                _first_title_line = True
                # v82: renglones extra ANTES del titulo (comando ---/// del
                # extracto anterior). Van en el spaceBefore de la 1ra linea:
                # el ajuste del titulo los cuenta solos (si no caben, el
                # titulo pasa entero a la otra pagina) y ReportLab los omite
                # si el titulo empieza pagina nueva (sin aire de mas arriba).
                _pre82 = min(5, int(ext.get('pre_lines') or 0)) * 18.0
                _stf82 = style_title_first
                if _pre82:
                    _stf82 = ParagraphStyle('tfpre' + str(ext_idx), parent=style_title_first,
                                            spaceBefore=style_title_first.spaceBefore + _pre82)
                for tl in ext['title_lines']:
                    if tl.strip():
                        # 1ra línea del título lleva el gap de un renglón (spaceBefore 14;
                        # reportlab lo omite si el título empieza página -> sin espacio extra)
                        title_flow.append(Paragraph(escape_text(tl.upper()), _stf82 if _first_title_line else style_title))
                        _first_title_line = False
                if ext['subtitle']:
                    title_flow.append(Paragraph(escape_text(ext['subtitle']), style_subtitle))
                if ext['author']:
                    title_flow.append(Paragraph(escape_text(ext['author']), style_author))
                if ext['date']:
                    title_flow.append(Paragraph(escape_text(ext['date']), style_date))
                if ext['city']:
                    title_flow.append(Paragraph(escape_text(ext['city']), style_city))
                if title_flow:
                    # v57: politica automatica + AJUSTE MANUAL por titulo
                    _tw = PAGE_W - (m_inner + m_outer)
                    _th = 0.0
                    for _f in title_flow:
                        _hw, _hh = _f.wrap(_tw, 10000)
                        _th += _hh + _f.getSpaceBefore() + _f.getSpaceAfter()
                    _aj = None
                    if ajustes:
                        _tl0 = ((ext.get('title_lines') or [''])[0] or '').strip().upper()
                        for _a in list(ajustes):
                            _at = (_a.get('titulo') or '').strip().upper()
                            if _at and _tl0 and (_tl0.startswith(_at[:24]) or _at.startswith(_tl0[:24])):
                                _aj = _a
                                ajustes = [x for x in ajustes if x is not _a]
                                break
                    _modo = (_aj or {}).get('modo') or 'auto'
                    _reng = (_aj or {}).get('renglon_pt')
                    # v58: 'renglon'/'llenar' -> interlineado del CUERPO en todo el extracto
                    _extr_L = None
                    if _modo in ('renglon', 'llenar'):
                        try:
                            _vL = float((_aj or {}).get('_llenar_L') or 0) if _modo == 'llenar' else float(_reng or 0)
                        except Exception:
                            _vL = 0.0
                        if _vL > 0:
                            _extr_L = min(30.0, max(12.0, _vL))
                    try:
                        _gap_h = float(_reng) if (_reng not in (None, '')) else max(4.0, max(18.0, float(title_gap)) - title_flow[-1].getSpaceAfter())
                    except Exception:
                        _gap_h = max(4.0, max(18.0, float(title_gap)) - title_flow[-1].getSpaceAfter())
                    _pares = []
                    for _i4, _f in enumerate(title_flow):
                        # v83: el modo APRETADO conserva los renglones extra
                        # ANTES del titulo (comando ---///, que viajan en el
                        # spaceBefore de la 1ra linea por encima del base).
                        # Antes se ponia spaceBefore=0 y el aire desaparecia
                        # justo cuando el titulo queda apretado al pie.
                        _keep83 = (_f.style.spaceBefore if (_i4 == 0 and _pre82) else 0.0)  # v83b: con ---/// se conserva TODO el espacio (base+aire); sin ---///, apretado como siempre
                        _ts = ParagraphStyle(_f.style.name + '_tight', parent=_f.style, spaceBefore=_keep83, leading=max(11.5, _f.style.leading - 1.5))
                        _pares.append((_f, _ts, _f.style))
                    _ahorro = sum((_orig.spaceBefore - _ts.spaceBefore) + (_orig.leading - _ts.leading) for _f, _ts, _orig in _pares)
                    _tight = _th - _ahorro + 16.5 + 2
                    _full = _th + _gap_h + 16.5 + 2
                    if _modo in ('renglon_arriba', 'regla2', 'regla10', 'regla11'):
                        # v59 (regla del usuario): apretado que CONSERVA el renglon
                        # de arriba (0.63cm) entre el texto anterior y el titulo.
                        # Si con el renglon no cabe, el titulo pasa ENTERO a la
                        # pagina siguiente (umbral apretado + el renglon).
                        _sb0 = 15.9 if _modo == 'regla11' else (title_flow[0].style.spaceBefore or 18.0)
                        _pares_gap = []
                        for _i2, (_f2, _ts2, _o2) in enumerate(_pares):
                            if _i2 == 0:
                                _tsg = ParagraphStyle(_o2.name + '_gapup', parent=_o2, leading=max(11.5, _o2.leading - 1.5))
                                _pares_gap.append((_f2, _tsg, _o2))
                            else:
                                _pares_gap.append((_f2, _ts2, _o2))
                        # v67: si la regla agrega renglon DESPUES del titulo,
                        # el umbral exige lugar para ese renglon + la 1ra linea
                        # del texto. Asi el titulo NUNCA queda solo al pie
                        # (ese era el fallo: el renglon quedaba varado y el
                        # texto saltaba a la otra pagina).
                        _gap_after = 0.0
                        if _modo == 'regla10':
                            _gap_after = _gap_h
                        elif _modo == 'regla11':
                            _gap_after = 15.9
                        # v77/v78: la 1ra linea (la que lleva SANGRIA) nunca
                        # queda sola al pie: el umbral exige DOS lineas del
                        # cuerpo despues del titulo MAS 33pt de holgura (2
                        # lineas completas), en modo normal y apretado. Si no
                        # cabe, el titulo pasa ENTERO a la pagina siguiente y
                        # la sangria viaja con el. La holgura cubre el error
                        # de estimacion que dejaba 1 linea huerfana en libros
                        # reales (v77 fallaba con +16.5).
                        story.append(FitTitulo(_full + 33.0, _tight + 33.0 + _sb0 + _gap_after))
                        story.append(AjustaTitulo(_pares_gap))
                        story.append(KeepTogether(title_flow))
                        if _gap_after:
                            story.append(Spacer(0, _gap_after))
                    elif _modo == 'pegado':
                        # orden del usuario: titulo pegado con su primer texto, sin renglon
                        for _f, _ts, _orig in _pares:
                            _f.style = _ts
                        story.append(KeepTogether(title_flow))
                    elif _modo == 'sin_renglon':
                        story.append(FitTitulo(_full, _full))
                        story.append(KeepTogether(title_flow))
                    elif _modo == 'con_renglon':
                        story.append(FitTitulo(_full, _full))
                        story.append(KeepTogether(title_flow))
                        story.append(Spacer(0, _gap_h))
                    else:
                        # auto, o pagina nueva ordenada por el usuario (o REGLA 1)
                        if _modo in ('nueva', 'regla1'):
                            story.append(CondPageBreak(frame_height - 3))
                        # v77: REGLA 12 tambien exige DOS lineas despues del
                        # titulo (la 1ra lleva sangria y nunca queda sola);
                        # el AUTO puro no se toca.
                        # v81 (pedido del usuario): el AUTO tambien identifica
                        # el titulo varado al pie: exige DOS lineas del cuerpo
                        # bajo el titulo (igual que las reglas desde v78). Si
                        # no caben 2, el titulo pasa ENTERO a la otra pagina y
                        # la sangria viaja con el.
                        _full77 = _full + 33.0
                        _tight77 = _tight + 33.0
                        story.append(FitTitulo(_full77, _tight77))
                        story.append(AjustaTitulo(_pares))
                        story.append(KeepTogether(title_flow))
                        story.append(GapTitulo(_gap_h))

            # Body paragraphs - v4 que funcionaba: chunks 400, sin espacio vertical, solo sangría
            if ext['body']:
                # v50: parrafos REALES (linea en blanco = nuevo parrafo con sangria)
                raw_paras = [p for p in re.split(r'\n\s*\n', ext['body']) if p.strip()]
                if not raw_paras:
                    raw_paras = [ext['body']]
                body_paras = []
                _st_b, _st_bf = style_body, style_body_first
                _pj = _prev_L.get(ext_idx) or {}
                _Lj = _extr_L if _extr_L else _pj.get('L')
                _Fj = None if _extr_L else _pj.get('F')
                if _Lj or _Fj:
                    _st_b = ParagraphStyle('body_aj' + str(ext_idx), parent=style_body, leading=(_Lj or 16.5), fontSize=(_Fj or 13))
                    _st_bf = ParagraphStyle('bodyf_aj' + str(ext_idx), parent=style_body_first, leading=(_Lj or 16.5), fontSize=(_Fj or 13))
                # v81 REGLA 9: el comando ---/// en el TEXTO = renglon(es)
                # adicionales en blanco. Los saltos escritos a mano el parser
                # los colapsa; este comando se respeta al pie de la letra
                # (cada ---/// = un renglon). Deben ir solos en su linea.
                _items9 = []
                for p in raw_paras:
                    _ps = p.strip()
                    if re.fullmatch(r'(?:---///\s*)+', _ps):
                        _items9.append(('sp', len(re.findall(r'---///', _ps))))
                    else:
                        _items9.append(('p', p))
                while _items9 and _items9[-1][0] == 'sp':
                    _items9.pop()  # renglones al final del extracto romperian el ajuste del titulo siguiente
                body_paras = []
                for _tip, _p in _items9:
                    if _tip == 'sp':
                        body_paras.append(Spacer(1, 18.0 * _p))
                    else:
                        fb = format_body_with_bold(_p.replace('\n', ' ').strip())
                        if fb:
                            body_paras.append(Paragraph(fb, _st_b))
                _pri = True
                for _o in body_paras:
                    if isinstance(_o, Paragraph):
                        _o.style = _st_bf if _pri else _st_b
                        _pri = False
                for para in body_paras:
                    story.append(para)
            # (sin Spacer al final: el gap lo da style_title_first.spaceBefore=18 del
            #  siguiente título; un Spacer aquí caería a inicio de página y arruinaría
            #  el ajuste imagen 1 "título a inicio de página SIN espacio extra")


    doc_template.addPageTemplates([template_cover, template_blank, template_odd, template_even])
    doc_template.build(story)
    return output_path

def create_notas_pages_pdf(num_pages, output_path, pagesize=None):
    """Crea PDF con páginas de NOTAS estilo imagen 2: título NOTAS + líneas"""
    if pagesize is None:
        pagesize = (PAGE_W, PAGE_H)
    if num_pages <= 0:
        # crear pdf vacío de 1 página en blanco para evitar errores, pero no se usará
        from reportlab.pdfgen import canvas as rl_canvas
        c = rl_canvas.Canvas(output_path, pagesize=pagesize)
        c.showPage()
        c.save()
        return output_path
    from reportlab.pdfgen import canvas as rl_canvas
    from reportlab.lib.colors import HexColor
    c = rl_canvas.Canvas(output_path, pagesize=pagesize)
    w, h = pagesize
    for _ in range(num_pages):
        # Título NOTAS - estilo imagen 2: centrado, mayúsculas, ligero
        c.setFont("Times-Roman", 18)
        # Si queremos similar a imagen: Helvetica ligera
        try:
            c.setFont("Helvetica", 20)
        except:
            c.setFont("Times-Roman", 18)
        c.setFillColor(HexColor("#222222"))
        c.drawCentredString(w/2, h - 0.7*inch, "NOTAS")
        # Líneas
        c.setStrokeColor(HexColor("#8a8a8a"))
        c.setLineWidth(0.5)
        left = 0.6 * inch
        right = w - 0.6 * inch
        top_y = h - 1.1 * inch
        bottom_y = 0.7 * inch
        num_lines = 22
        step = (top_y - bottom_y) / num_lines
        for i in range(num_lines):
            y = top_y - i*step
            c.line(left, y, right, y)
        c.showPage()
    c.save()
    return output_path

def pad_pdf_to_multiple_of_4(pdf_path, padded_path, use_notas=True, extra_notas=0):
    """Pad a múltiplo de 4 usando páginas de NOTAS por defecto (en vez de blancos)"""
    reader = PdfReader(pdf_path)
    n = len(reader.pages)
    total_with_extra = n + extra_notas
    remainder = total_with_extra % 4
    needed = (4 - remainder) % 4 if remainder != 0 else 0

    total_notas = extra_notas + (needed if use_notas else 0)
    total_blanks = 0 if use_notas else needed

    writer = PdfWriter()
    for p in reader.pages:
        writer.add_page(p)

    # Agregar notas
    if total_notas > 0:
        notas_tmp = str(Path(pdf_path).parent / f"notas_{uuid.uuid4().hex}.pdf")
        create_notas_pages_pdf(total_notas, notas_tmp, pagesize=(PAGE_W, PAGE_H))
        notas_reader = PdfReader(notas_tmp)
        for p in notas_reader.pages:
            writer.add_page(p)
        try:
            os.remove(notas_tmp)
        except:
            pass

    # Agregar blancos si no se usan notas
    if total_blanks > 0:
        from reportlab.pdfgen import canvas as rl_canvas
        blank_path = str(Path(pdf_path).parent / f"blank_{uuid.uuid4().hex}.pdf")
        c = rl_canvas.Canvas(blank_path, pagesize=(PAGE_W, PAGE_H))
        for _ in range(total_blanks):
            c.showPage()
        c.save()
        br = PdfReader(blank_path)
        for p in br.pages:
            writer.add_page(p)
        try:
            os.remove(blank_path)
        except:
            pass

    # Si no hubo nada que agregar y es el mismo archivo, copiar
    if total_notas == 0 and total_blanks == 0:
        if pdf_path != padded_path:
            shutil.copy(pdf_path, padded_path)
        return padded_path, n

    with open(padded_path, 'wb') as f:
        writer.write(f)
    return padded_path, n + total_notas + total_blanks

def append_notas_to_digital(digital_path, num_notas, output_path):
    """Añade páginas de NOTAS al final del PDF digital"""
    if num_notas <= 0:
        if digital_path != output_path:
            shutil.copy(digital_path, output_path)
        return output_path
    reader = PdfReader(digital_path)
    writer = PdfWriter()
    for p in reader.pages:
        writer.add_page(p)
    notas_tmp = str(Path(digital_path).parent / f"notas_{uuid.uuid4().hex}.pdf")
    create_notas_pages_pdf(num_notas, notas_tmp, pagesize=(PAGE_W, PAGE_H))
    notas_reader = PdfReader(notas_tmp)
    for p in notas_reader.pages:
        writer.add_page(p)
    with open(output_path, 'wb') as f:
        writer.write(f)
    try:
        os.remove(notas_tmp)
    except:
        pass
    return output_path

def create_folleto_pdf(digital_pdf_path, folleto_pdf_path, use_notas=True):
    """Create folleto 11x8.5 - VERSIÓN COMPACTA SIN BLANCOS (8 hojas) como pediste antes
       Quita página en blanco #2 y blancos de padding para que no haya páginas en blanco al final
       Digital 17p -> quita blanco (16p) -> Booklet 8 hojas (16/2) todo lleno, sin blancos
       Si quieres referencia exacta con blancos, usa create_folleto_referencia
    """
    return create_folleto_compacto(digital_pdf_path, folleto_pdf_path, use_notas=use_notas)

def create_folleto_compacto(digital_pdf_path, folleto_pdf_path, use_notas=True):
    """Folleto IGUAL AL LIBRO DE REFERENCIA (7.Foll / Foll.UNÁNIMES JUNTOS):
       imposicion saddle sobre el digital COMPLETO (conserva la pág 2 en blanco
       que va tras la portada) y pad a múltiplo de 4 con blancos (o NOTAS).
       17p -> 20 -> 10 hojas: [b|portada], [b|b], [b|1ra pág], [164|177], [176|165]...
       11x8.5 landscape, 2 páginas por hoja. pymupdf primero, fallback PyPDF2.
    """
    digital_for_booklet = digital_pdf_path
    tmp_path = None
    padded_path = None
    try:
        # --- v51: NO se quita la pág 2 en blanco ---
        # La referencia 7.Foll.EL TÍTULO (10 hojas) conserva la página en blanco
        # tras la portada: hoja 1 = [blanco|portada], hoja 2 = [blanco|blanco],
        # hoja 3 = [blanco|1ra pág del libro a la DERECHA], hoja 4 = [164|177]...
        digital_for_booklet = digital_pdf_path

        # --- Paso 2 (v51): pad a múltiplo de 4 (usa NOTAS si use_notas=True) ---
        # Igual que la referencia: 17p -> 20 (3 blancos), 16p -> 16 (sin pad).
        reader = PdfReader(digital_for_booklet)
        n = len(reader.pages)
        pad_n = (4 - (n % 4)) % 4
        if pad_n != 0:
            if use_notas:
                notas_tmp = str(Path(digital_for_booklet).parent / f"notas_{uuid.uuid4().hex}.pdf")
                create_notas_pages_pdf(pad_n, notas_tmp, pagesize=(PAGE_W, PAGE_H))
                pad_src = notas_tmp
            else:
                from reportlab.pdfgen import canvas as rl_canvas
                blank_path = str(Path(digital_for_booklet).parent / f"blank_{uuid.uuid4().hex}.pdf")
                _c = rl_canvas.Canvas(blank_path, pagesize=(PAGE_W, PAGE_H))
                for _ in range(pad_n):
                    _c.showPage()
                _c.save()
                pad_src = blank_path
            writer = PdfWriter()
            for p in reader.pages:
                writer.add_page(p)
            br = PdfReader(pad_src)
            for p in br.pages:
                writer.add_page(p)
            padded_path = str(Path(digital_for_booklet).parent / f"padded_{uuid.uuid4().hex}.pdf")
            with open(padded_path, 'wb') as f:
                writer.write(f)
            try:
                os.remove(pad_src)
            except:
                pass
            digital_for_booklet_padded = padded_path
        else:
            if padded_path is None:
                padded_path = str(Path(digital_for_booklet).parent / f"padded_{uuid.uuid4().hex}.pdf")
                import shutil
                shutil.copy(digital_for_booklet, padded_path)
            digital_for_booklet_padded = padded_path

        # --- Paso 3: intentar pymupdf (más rápido y calidad) ---
        try:
            import pymupdf
            src_doc = pymupdf.open(digital_for_booklet_padded)
            n = len(src_doc)
            dst_doc = pymupdf.open()
            for s in range(n // 2):
                if s % 2 == 0:
                    left_idx = n - 1 - s
                    right_idx = s
                else:
                    left_idx = s
                    right_idx = n - 1 - s
                page = dst_doc.new_page(width=FOLLETO_W, height=FOLLETO_H)
                left_rect = pymupdf.Rect(0, 0, PAGE_W, PAGE_H)
                right_rect = pymupdf.Rect(PAGE_W, 0, FOLLETO_W, PAGE_H)
                page.show_pdf_page(right_rect, src_doc, right_idx)
                page.show_pdf_page(left_rect, src_doc, left_idx)
            dst_doc.save(folleto_pdf_path)
            dst_doc.close()
            src_doc.close()
            print(f"[Folleto compacto pymupdf] {n} -> {n//2} hojas OK")
            return folleto_pdf_path
        except Exception as e_pymupdf:
            print(f"[Folleto compacto] pymupdf falló: {e_pymupdf}, usando PyPDF2 fallback robusto")

        # --- Paso 4: fallback PyPDF2 robusto con mediabox expandido (funciona sin pymupdf) ---
        # Re-leer el PDF ya sin blanco y con pad
        # Para evitar acumulación de transformaciones, leer fresco en cada iteración
        final_reader = PdfReader(digital_for_booklet_padded)
        n = len(final_reader.pages)
        writer_booklet = PdfWriter()
        for s in range(n // 2):
            if s % 2 == 0:
                left_idx = n - 1 - s
                right_idx = s
            else:
                left_idx = s
                right_idx = n - 1 - s

            # leer fresco cada hoja para páginas limpias
            rf = PdfReader(digital_for_booklet_padded)
            left_page = rf.pages[left_idx]
            right_page = rf.pages[right_idx]

            # Expandir mediabox a 792 para que traslación 396 no recorte
            left_page.mediabox.upper_right = (792, 612)
            right_page.mediabox.upper_right = (792, 612)

            new_page = PageObject.create_blank_page(width=FOLLETO_W, height=FOLLETO_H)
            # derecha a 396
            right_page.add_transformation(Transformation().translate(396, 0))
            new_page.merge_page(left_page)
            new_page.merge_page(right_page)
            writer_booklet.add_page(new_page)

        with open(folleto_pdf_path, 'wb') as f:
            writer_booklet.write(f)
        print(f"[Folleto compacto PyPDF2] {n} -> {n//2} hojas OK")
        return folleto_pdf_path

    except Exception as e:
        print(f"[Folleto compacto] Error total: {e}")
        import traceback; traceback.print_exc()
        # último recurso: copiar pero con mensaje
        try:
            import shutil
            shutil.copy(digital_pdf_path, folleto_pdf_path)
        except:
            pass
        return folleto_pdf_path
    finally:
        # limpieza
        try:
            if padded_path and os.path.exists(padded_path):
                os.remove(padded_path)
        except:
            pass
        try:
            if tmp_path and os.path.exists(tmp_path):
                os.remove(tmp_path)
        except:
            pass

def create_folleto_referencia(digital_pdf_path, folleto_pdf_path, use_notas=True):
    """Booklet referencia exacta 10 hojas como 7.Foll...pdf con blancos (Adobe Reader Folleto)
       17p -> pad 20p -> 10 hojas 11x8.5 con blancos al inicio, 164+177 misma hoja
       Si use_notas=True, rellena blancos con páginas de NOTAS
    """
    padded_path = str(Path(digital_pdf_path).parent / f"padded_{uuid.uuid4().hex}.pdf")
    padded_path, total = pad_pdf_to_multiple_of_4(digital_pdf_path, padded_path, use_notas=use_notas, extra_notas=0)
    
    try:
        import pymupdf
        src_doc = pymupdf.open(padded_path)
        n = len(src_doc)
        dst_doc = pymupdf.open()
        for s in range(n // 2):
            if s % 2 == 0:
                left_idx = n - 1 - s
                right_idx = s
            else:
                left_idx = s
                right_idx = n - 1 - s
            page = dst_doc.new_page(width=FOLLETO_W, height=FOLLETO_H)
            left_rect = pymupdf.Rect(0, 0, PAGE_W, PAGE_H)
            right_rect = pymupdf.Rect(PAGE_W, 0, FOLLETO_W, PAGE_H)
            page.show_pdf_page(right_rect, src_doc, right_idx)
            page.show_pdf_page(left_rect, src_doc, left_idx)
        dst_doc.save(folleto_pdf_path)
        dst_doc.close()
        src_doc.close()
        print(f"[Folleto ref pymupdf] {n} -> {n//2} hojas OK")
        return folleto_pdf_path
    except Exception as e:
        print(f"[Folleto ref] pymupdf falló: {e}, usando PyPDF2 fallback")
        try:
            # Fallback PyPDF2 robusto
            rf = PdfReader(padded_path)
            n = len(rf.pages)
            writer_booklet = PdfWriter()
            for s in range(n // 2):
                if s % 2 == 0:
                    left_idx = n - 1 - s
                    right_idx = s
                else:
                    left_idx = s
                    right_idx = n - 1 - s
                rf2 = PdfReader(padded_path)
                left_page = rf2.pages[left_idx]
                right_page = rf2.pages[right_idx]
                left_page.mediabox.upper_right = (792, 612)
                right_page.mediabox.upper_right = (792, 612)
                new_page = PageObject.create_blank_page(width=FOLLETO_W, height=FOLLETO_H)
                right_page.add_transformation(Transformation().translate(396, 0))
                new_page.merge_page(left_page)
                new_page.merge_page(right_page)
                writer_booklet.add_page(new_page)
            with open(folleto_pdf_path, 'wb') as f:
                writer_booklet.write(f)
            print(f"[Folleto ref PyPDF2] {n} -> {n//2} hojas OK")
            return folleto_pdf_path
        except Exception as e2:
            print(f"[Folleto ref] Error PyPDF2: {e2}")
            import traceback; traceback.print_exc()
            import shutil
            shutil.copy(padded_path, folleto_pdf_path)
            return folleto_pdf_path
    finally:
        if os.path.exists(padded_path):
            os.remove(padded_path)


# ============================ HERRAMIENTA TOMO ============================
# Un TOMO = compilación de N folletos con paginación CONTINUA + índice + prefacio opcional
# No toca el código de creación de folleto existente: reutiliza create_digital_pdf y create_folleto_pdf
from reportlab.pdfgen import canvas as rl_canvas

def _tomo_styles():
    """Estilos idénticos al digital para que la paginación continua sea exacta"""
    styles = {}
    styles['body'] = ParagraphStyle('t_body', fontName='Times-Roman', fontSize=13, leading=16.5,
        alignment=TA_JUSTIFY, spaceAfter=0, spaceBefore=0, firstLineIndent=22, allowOrphans=1)
    styles['body_first'] = ParagraphStyle('t_body_first', fontName='Times-Roman', fontSize=13, leading=16.5,
        alignment=TA_JUSTIFY, spaceAfter=0, spaceBefore=0, firstLineIndent=22, allowOrphans=1)  # v50 sangria + v54 orfanas
    styles['title'] = ParagraphStyle('t_title', fontName='Times-Bold', fontSize=13, leading=14,
        alignment=TA_CENTER, spaceBefore=0, spaceAfter=2)
    styles['title_first'] = ParagraphStyle('t_title_first', fontName='Times-Bold', fontSize=13, leading=14,
        alignment=TA_CENTER, spaceBefore=18, spaceAfter=2)  # gap 18pt (sin Spacer: ver digital)
    styles['subtitle'] = ParagraphStyle('t_sub', fontName='Times-Italic', fontSize=13, leading=14,
        alignment=TA_CENTER, spaceAfter=2, spaceBefore=0)
    styles['author'] = ParagraphStyle('t_author', fontName='Times-Italic', fontSize=13, leading=14,
        alignment=TA_CENTER, spaceAfter=0, spaceBefore=0)
    styles['date'] = ParagraphStyle('t_date', fontName='Times-Italic', fontSize=13, leading=14,
        alignment=TA_CENTER, spaceAfter=0, spaceBefore=0)
    styles['city'] = ParagraphStyle('t_city', fontName='Times-Italic', fontSize=13, leading=14,
        alignment=TA_CENTER, spaceAfter=4, spaceBefore=0)
    styles['cover_sub'] = ParagraphStyle('t_cover_sub', fontName='Times-Roman', fontSize=16, leading=20,
        alignment=TA_CENTER, spaceAfter=12)
    styles['cover_title'] = ParagraphStyle('t_cover_title', fontName='Times-Bold', fontSize=30, leading=34,
        alignment=TA_CENTER, spaceAfter=24)
    styles['idx_head'] = ParagraphStyle('t_idx_head', fontName='Times-Bold', fontSize=16, leading=20,
        alignment=TA_CENTER, spaceAfter=14)
    styles['idx_left'] = ParagraphStyle('t_idx_left', fontName='Times-Roman', fontSize=13, leading=20,
        alignment=TA_LEFT)
    styles['idx_right'] = ParagraphStyle('t_idx_right', fontName='Times-Bold', fontSize=13, leading=20,
        alignment=TA_RIGHT)
    return styles

def _extract_flowables(ext, styles, title_gap=18.0):
    """Convierte un extracto en flowables (idéntico al digital)"""
    from reportlab.platypus import KeepTogether
    flow = []
    title_flow = []
    _first_title_line = True
    # v82: renglones extra ANTES del titulo (comando ---/// del extracto
    # anterior); mismo mecanismo que el digital (spaceBefore de la 1ra linea).
    _pre82 = min(5, int(ext.get('pre_lines') or 0)) * 18.0
    _stf82 = styles['title_first']
    if _pre82:
        _stf82 = ParagraphStyle('tomotfpre', parent=styles['title_first'],
                                spaceBefore=styles['title_first'].spaceBefore + _pre82)
    for tl in (ext.get('title_lines') or []):
        if tl.strip():
            # 1ra línea del título lleva el gap de un renglón (spaceBefore 14,
            # omitido automáticamente si el título empieza página)
            title_flow.append(Paragraph(escape_text(tl.upper()), _stf82 if _first_title_line else styles['title']))
            _first_title_line = False
    for key, st in [('subtitle','subtitle'), ('author','author'), ('date','date'), ('city','city')]:
        if ext.get(key):
            title_flow.append(Paragraph(escape_text(ext[key]), styles[st]))
    if title_flow:
        # v56: modo APRETADO como el digital (sin renglon antes/despues y
        # bloque comprimido) para aprovechar huecos pequenos al final de pagina
        _tw = PAGE_W - (DEFAULT_MARGINS['inner'] + DEFAULT_MARGINS['outer']) * inch
        _th = 0.0
        for _f in title_flow:
            _hw, _hh = _f.wrap(_tw, 10000)
            _th += _hh + _f.getSpaceBefore() + _f.getSpaceAfter()
        _gap_h = max(4.0, max(18.0, float(title_gap)) - title_flow[-1].getSpaceAfter())
        _pares = []
        for _i4, _f in enumerate(title_flow):
            # v83: mismo fix que el digital (el apretado conserva el aire ---///)
            _keep83 = (_f.style.spaceBefore if (_i4 == 0 and _pre82) else 0.0)  # v83b: con ---/// se conserva TODO el espacio
            _ts = ParagraphStyle(_f.style.name + '_tight', parent=_f.style, spaceBefore=_keep83, leading=max(11.5, _f.style.leading - 1.5))
            _pares.append((_f, _ts, _f.style))
        _ahorro = sum((_orig.spaceBefore - _ts.spaceBefore) + (_orig.leading - _ts.leading) for _f, _ts, _orig in _pares)
        _tight = _th - _ahorro + 16.5 + 2
        _full = _th + _gap_h + 16.5 + 2
        flow.append(FitTitulo(_full, _tight))
        flow.append(AjustaTitulo(_pares))
        flow.append(KeepTogether(title_flow))
        flow.append(GapTitulo(_gap_h))
    if ext.get('body'):
        # v50: parrafos REALES (linea en blanco = nuevo parrafo con sangria)
        raw_paras = [p for p in re.split(r'\n\s*\n', ext['body']) if p.strip()]
        if not raw_paras:
            raw_paras = [ext['body']]
        # v81 REGLA 9: el comando ---/// en el TEXTO = renglon(es) adicionales
        # en blanco (cada ---/// solo en su linea = un renglon).
        _items9 = []
        for p in raw_paras:
            _ps = p.strip()
            if re.fullmatch(r'(?:---///\s*)+', _ps):
                _items9.append(('sp', len(re.findall(r'---///', _ps))))
            else:
                _items9.append(('p', p))
        while _items9 and _items9[-1][0] == 'sp':
            _items9.pop()
        body_paras = []
        for _tip, _p in _items9:
            if _tip == 'sp':
                body_paras.append(Spacer(1, 18.0 * _p))
            else:
                fb = format_body_with_bold(_p.replace('\n', ' ').strip())
                if fb:
                    body_paras.append(Paragraph(fb, styles['body']))
        _pri = True
        for _o in body_paras:
            if isinstance(_o, Paragraph):
                if _pri:
                    _o.style = styles['body_first']
                    _pri = False
        flow.extend(body_paras)
    # (sin Spacer al final: el gap lo da styles['title_first'].spaceBefore=18)
    return flow

def create_content_pdf(extracts, output_path, margins, base_num, base_pos, running_title, title_gap=18):
    """Páginas de CONTENIDO del tomo (sin portada): header continuo en todas las páginas.
       base_num = número de página que lleva la 1ra página; base_pos = posición física 0-based dentro del tomo fusionado (para paridad izq/der)"""
    # Renglón antes de títulos AJUSTABLE: mínimo 1 renglón (18pt)
    title_gap = max(18.0, float(title_gap))
    m_top = margins.get('top', DEFAULT_MARGINS['top']) * inch
    m_bottom = margins.get('bottom', DEFAULT_MARGINS['bottom']) * inch
    m_inner = margins.get('inner', DEFAULT_MARGINS['inner']) * inch
    m_outer = margins.get('outer', DEFAULT_MARGINS['outer']) * inch
    styles = _tomo_styles()
    # aplicar el renglón ajustable (mínimo 1 renglón = 18pt) al estilo del título
    styles['title_first'].spaceBefore = title_gap

    def hdr(canvas, doc):
        k = doc.page - 1  # 0-based dentro de este contenido
        if k == 0:
            return  # 1ra página de cada folleto sin header (igual al digital standalone)
        pos = base_pos + k + 1  # posición física 1-based dentro del tomo fusionado
        num = base_num + k - 1  # misma numeración que el digital standalone
        is_odd = (pos % 2 == 1)
        canvas.saveState()
        # v68b: igual que el digital - tinta del cuerpo en m_top exacta
        header_y = PAGE_H - m_top + _M_INK_TOP_LAG + 14
        line_y = header_y - 6
        canvas.setStrokeColor(HexColor('#000000'))
        canvas.setLineWidth(0.6)
        if is_odd:
            canvas.line(m_inner, line_y, PAGE_W - m_outer, line_y)
        else:
            canvas.line(m_outer, line_y, PAGE_W - m_inner, line_y)
        canvas.setFont('Times-Bold', 11)
        canvas.setFillColor(HexColor('#000000'))
        if is_odd:
            canvas.drawString(m_inner, header_y, running_title[:55])
            canvas.drawRightString(PAGE_W - m_outer, header_y, str(num))
        else:
            canvas.drawString(m_outer, header_y, str(num))
            canvas.drawRightString(PAGE_W - m_inner, header_y, "Extractos para Estudio:")
        canvas.restoreState()

    # v68b: frames espejados por posicion fisica en el tomo (pos 1-based impar =
    # recto -> x=m_inner; par -> x=m_outer), padding 0 y lag de tinta igual que
    # el digital. Pag 1 usa templates[0]; desde la pag 2 alterna el CICLO real
    # (ReportLab NO lee .nextPageTemplate de los PageTemplate).
    _fw = PAGE_W - m_inner - m_outer
    _top_fb = PAGE_H - m_top + _M_INK_TOP_LAG
    _y1_fb = m_bottom - _M_INK_BOT_LAG
    _fh = _top_fb - _y1_fb
    _fargs = dict(leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    frame_r = Frame(m_inner, _y1_fb, _fw, _fh, id='cr', **_fargs)
    frame_v = Frame(m_outer, _y1_fb, _fw, _fh, id='cv', **_fargs)
    tpl_r = PageTemplate(id='cr', frames=[frame_r], onPage=hdr, pagesize=(PAGE_W, PAGE_H))
    tpl_v = PageTemplate(id='cv', frames=[frame_v], onPage=hdr, pagesize=(PAGE_W, PAGE_H))
    doc = BaseDocTemplate(output_path, pagesize=(PAGE_W, PAGE_H), leftMargin=m_outer,
        rightMargin=m_outer, topMargin=m_top, bottomMargin=m_bottom, showBoundary=0)
    if (base_pos + 1) % 2 == 1:
        doc.addPageTemplates([tpl_r, tpl_v])
        _cycle = ['cv', 'cr']
    else:
        doc.addPageTemplates([tpl_v, tpl_r])
        _cycle = ['cr', 'cv']
    story = [NextPageTemplate(_cycle)]
    for ext in extracts:
        story.extend(_extract_flowables(ext, styles, title_gap))
    if not story:
        story.append(Paragraph("", styles['body']))
    doc.build(story)
    return output_path

def _wrap_canvas_lines(canvas, text, font, size, max_w):
    words = str(text).split()
    lines, cur = [], ''
    for w in words:
        t = (cur + ' ' + w).strip()
        if canvas.stringWidth(t, font, size) <= max_w:
            cur = t
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines or ['']

def create_blank_pdf(output_path, n_pages=1):
    c = rl_canvas.Canvas(output_path, pagesize=(PAGE_W, PAGE_H))
    for _ in range(n_pages):
        c.showPage()
    c.save()
    return output_path

def create_tomo_portada_pdf(tomo_title, tomo_subtitle, label, logo_path, output_path):
    """Portada TOMO igual al ejemplo: etiqueta arriba a la izquierda, título/subtítulo centrados"""
    m_outer = DEFAULT_MARGINS['outer'] * inch
    c = rl_canvas.Canvas(output_path, pagesize=(PAGE_W, PAGE_H))
    max_w = PAGE_W - 2*m_outer
    c.setFont('Times-Bold', 21)
    c.drawString(m_outer, PAGE_H - 107, label)
    y = PAGE_H - 259
    c.setFont('Times-Bold', 32)
    for ln in _wrap_canvas_lines(c, tomo_title.strip().upper(), 'Times-Bold', 32, max_w):
        c.drawCentredString(PAGE_W/2, y, ln)
        y -= 40
    if tomo_subtitle and tomo_subtitle.strip():
        y_sub = y + 9
        c.setFont('Times-Bold', 24)
        for ln in _wrap_canvas_lines(c, tomo_subtitle.strip(), 'Times-Bold', 24, max_w):
            c.drawCentredString(PAGE_W/2, y_sub, ln)
            y_sub -= 32
    if logo_path and os.path.exists(logo_path):
        try:
            from PIL import Image as PILImage
            im = PILImage.open(logo_path)
            w, h = im.size
            lw = 1.5*inch
            lh = lw*h/w if w else lw
            c.drawImage(logo_path, PAGE_W/2 - lw/2, 60, width=lw, height=lh, mask='auto')
        except Exception:
            pass
    c.showPage()
    c.save()
    return output_path

def create_folleto_divisor_pdf(title, output_path):
    """Página separadora de cada folleto igual al ejemplo: 'Extractos para Estudio:' + título grande"""
    m_outer = DEFAULT_MARGINS['outer'] * inch
    c = rl_canvas.Canvas(output_path, pagesize=(PAGE_W, PAGE_H))
    max_w = PAGE_W - 2*m_outer
    c.setFont('Times-Bold', 18)
    c.drawString(m_outer, PAGE_H - 105, "Extractos para Estudio:")
    y = PAGE_H - 275
    c.setFont('Times-Bold', 28)
    for ln in _wrap_canvas_lines(c, title.strip().upper(), 'Times-Bold', 28, max_w):
        c.drawCentredString(PAGE_W/2, y, ln)
        y -= 36
    c.showPage()
    c.save()
    return output_path

def create_indice_pdf(entries, output_path):
    """ÍNDICE igual al ejemplo: 'INDICE' centrado + 'N-' + título COMPLETO (envuelto en
    varias líneas si es largo, como un índice de libro real) + puntos + pág (negrita).
    Paginación por altura: 13 entradas de 1 línea por pág (igual que antes); si una
    entrada ocupa más líneas, fluye a la página siguiente automáticamente."""
    from reportlab.pdfbase.pdfmetrics import stringWidth
    m_outer = DEFAULT_MARGINS['outer'] * inch
    right = PAGE_W - m_outer
    x0 = m_outer + 36
    LINE_H = 20   # alto de línea extra cuando el título se envuelve
    STEP = 33     # separación estándar entre entradas
    Y_MIN = 60    # límite inferior de la página
    c = rl_canvas.Canvas(output_path, pagesize=(PAGE_W, PAGE_H))
    primera_pag = True
    y = PAGE_H - 121
    for n, (title, pag) in enumerate(entries, start=1):
        page_str = str(pag)
        pw = stringWidth(page_str, 'Times-Bold', 14)
        # ancho máximo por línea de título (reserva el número + puntos mínimos)
        w_max = right - x0 - pw - 18
        # envolver el título completo en líneas que quepan
        words = (title or '').split()
        lines, cur = [], ''
        for w in words:
            if stringWidth(w, 'Times-Roman', 14) > w_max:
                while w and stringWidth(w + '…', 'Times-Roman', 14) > w_max:
                    w = w[:-1]
                w += '…'  # palabra individual larguísima: caso extremo
            test = (cur + ' ' + w).strip()
            if stringWidth(test, 'Times-Roman', 14) <= w_max or not cur:
                cur = test
            else:
                lines.append(cur)
                cur = w
        if cur:
            lines.append(cur)
        if not lines:
            lines = ['']
        needed = LINE_H * (len(lines) - 1)
        # ¿cabe completa en esta página? si no, nueva página (sin cabecera INDICE)
        if not primera_pag and (y - needed) < Y_MIN:
            c.showPage()
            y = PAGE_H - 75
            primera_pag = True
        if primera_pag:
            if n == 1:
                c.setFont('Times-Bold', 18)
                c.drawCentredString(PAGE_W/2, PAGE_H - 75, 'INDICE')
                y = PAGE_H - 121
            else:
                y = PAGE_H - 75
            primera_pag = False
        # dibujar entrada
        c.setFont('Times-Bold', 14)
        c.drawString(m_outer, y, f"{n}-")
        c.setFont('Times-Roman', 14)
        yy = y
        for li, ln in enumerate(lines):
            if li == len(lines) - 1:
                dot_w = stringWidth('.', 'Times-Roman', 14)
                ndots = max(3, int((right - pw - 4 - x0 - stringWidth(ln, 'Times-Roman', 14)) / dot_w))
                c.drawString(x0, yy, ln + '.'*ndots)
            else:
                c.drawString(x0, yy, ln)
                yy -= LINE_H
        c.setFont('Times-Bold', 14)
        c.drawRightString(right, yy, page_str)
        y = yy - STEP
    c.save()
    return output_path

def create_prefacio_pdf(prefacio_text, output_path, margins):
    m_top = margins.get('top', DEFAULT_MARGINS['top']) * inch
    m_bottom = margins.get('bottom', DEFAULT_MARGINS['bottom']) * inch
    m_inner = margins.get('inner', DEFAULT_MARGINS['inner']) * inch
    m_outer = margins.get('outer', DEFAULT_MARGINS['outer']) * inch
    styles = _tomo_styles()
    frame = Frame(m_outer, m_bottom, PAGE_W - m_inner - m_outer, PAGE_H - m_top - m_bottom - 12, id='pf')
    tpl = PageTemplate(id='pf', frames=[frame], pagesize=(PAGE_W, PAGE_H))
    doc = BaseDocTemplate(output_path, pagesize=(PAGE_W, PAGE_H), showBoundary=0)
    doc.addPageTemplates([tpl])
    story = [Paragraph("PREFACIO", styles['idx_head'])]
    for block in [b.strip() for b in prefacio_text.split('\n\n') if b.strip()]:
        html = format_body_with_bold(block.replace('\n', ' '))
        story.append(Paragraph(html, styles['body']))
        story.append(Spacer(1, 4))
    doc.build(story)
    return output_path

def merge_pdfs(paths, output_path):
    """Concatena PDFs. Usa pymupdf si está disponible (rápido y estable).
    Si NO está (PC local), usa PyPDF2 en un SUBPROCESO (proceso fresco: evita el bug de
    PyPDF2 que corrompe páginas cuando se mezcla mucho en el mismo proceso)."""
    try:
        import pymupdf
    except ImportError:
        import subprocess, sys
        snippet = (
            "import sys\n"
            "from PyPDF2 import PdfReader, PdfWriter\n"
            "w = PdfWriter()\n"
            "for p in sys.argv[1:-1]:\n"
            "    for pg in PdfReader(p).pages:\n"
            "        w.add_page(pg)\n"
            "with open(sys.argv[-1], 'wb') as f:\n"
            "    w.write(f)\n"
        )
        try:
            subprocess.run([sys.executable, '-c', snippet] + [str(p) for p in paths] + [str(output_path)], check=True, timeout=120)
        except subprocess.TimeoutExpired:
            raise RuntimeError('La concatenacion tardo mas de 120s (posible antivirus bloqueando Python). Cancelado.')
        return output_path
    out = pymupdf.open()
    for pp in paths:
        src = pymupdf.open(pp)
        out.insert_pdf(src)
        src.close()
    out.save(output_path, garbage=3, deflate=True)
    out.close()
    return output_path

@app.route('/tomo')
def tomo():
    r = make_response(render_template('tomo.html'))
    r.headers['Cache-Control'] = 'no-store, max-age=0'
    return r

def _scan_digital_pages(pdf_path, extracts, bottom_y):
    """v64: mapa {pagina_fisica: {'titulo','espacio','todos':[...]}} para el
    Ajustador. AHORA incluye TODOS los titulos que caen en cada pagina
    (el que inicia la pagina Y los que empiezan a mitad), porque cualquiera
    se puede ajustar desde el panel."""
    out = {}
    try:
        import pymupdf as _pm
        doc = _pm.open(pdf_path)
        _last = 2
        _regs = []  # [(pagina, titulo_completo)] en orden del libro
        for _ext in extracts:
            _t_linea = ((_ext.get('title_lines') or [''])[0] or '').strip().upper()
            _t0 = _t_linea[:24]
            if not _t0:
                continue
            _found = None
            for _p in range(_last, len(doc)):
                # normalizar espacios: los títulos comprimidos pueden partirse en 2 líneas
                if _t0 in ' '.join(doc[_p].get_text().upper().split()):
                    _found = _p + 1
                    break
            if _found:
                _last = max(2, _found - 1)
                _regs.append((_found, _t_linea or _t0))
        from collections import OrderedDict
        _per = OrderedDict()
        for _pg, _tt in _regs:
            _per.setdefault(_pg, []).append(_tt)
        for _pg in sorted(_per.keys()):
            _tts = _per[_pg]
            _pgd = doc[_pg - 1]
            # excluir el folio (nº de pagina: solo digitos abajo del area util)
            _ys = [s['bbox'][3] for b in _pgd.get_text('dict')['blocks'] for l in b.get('lines', []) for s in l['spans'] if s['text'].strip() and s['bbox'][1] > 45 and not (s['text'].strip().isdigit() and s['bbox'][1] > 540)]
            out[str(_pg)] = {'titulo': _tts[0], 'espacio': (round(max(0.0, bottom_y - max(_ys)), 1) if _ys else None), 'todos': _tts}
        doc.close()
    except Exception as _e:
        print(f"[scan paginas] {_e}")
    return out

@app.route('/api/tomo', methods=['POST'])
def api_tomo():
    try:
        data = request.get_json(force=True)
        tomo_title = (data.get('tomo_title') or 'TOMO').strip()
        tomo_subtitle = (data.get('tomo_subtitle') or '').strip()
        portada_label = (data.get('portada_label') or 'TOMO ESPECIAL:').strip()
        start_page = int(data.get('start_page') or 4)
        notas_global = int(data.get('notas_global') or 0)
        use_notas_blanks = bool(data.get('use_notas_for_blanks', True))
        prefacion = (data.get('prefacion') or '').strip()
        folletos_in = data.get('folletos') or []
        margins = DEFAULT_MARGINS
        # Renglón antes de títulos ajustable (en renglones; mínimo 1 = 18pt)
        try:
            _tgl = float(data.get('title_gap_lines') or 1)
        except Exception:
            _tgl = 1.0
        title_gap = max(1.0, _tgl) * 18.0
        # v57: ordenes manuales del Ajustador de paginas
        ajustes_in = data.get('ajustes') or []
        if not isinstance(ajustes_in, list):
            ajustes_in = []
        uid = uuid.uuid4().hex[:8]

        logo_path = None
        logo_data = data.get('logo_data')
        if logo_data:
            import base64 as b64
            try:
                raw = logo_data.split(',', 1)[1] if ',' in logo_data else logo_data
                lp = OUTPUT_DIR / f"{uid}_tomo_logo.png"
                lp.write_bytes(b64.b64decode(raw))
                logo_path = str(lp)
            except Exception:
                logo_path = None

        if not folletos_in:
            return jsonify({'error': 'Agrega al menos un folleto'}), 400

        # --- Parsear extractos de cada folleto ---
        folletos = []
        for i, f in enumerate(folletos_in):
            txt = (f.get('text') or '').strip()
            if not txt:
                return jsonify({'error': f'Folleto {i+1} sin texto'}), 400
            tmp = OUTPUT_DIR / f"{uid}_f{i}_src.txt"
            tmp.write_text(txt, encoding='utf-8')
            extracts, auto_title = parse_txt_advanced(str(tmp))
            os.remove(str(tmp))
            if not extracts:
                # El texto no tenía títulos reconocibles: todo el texto = un solo extracto
                extracts = [{'title_lines': [], 'subtitle': None, 'author': None,
                             'date': None, 'city': None, 'body': txt}]
            notas_i = f.get('notas', None)
            notas_i = notas_global if (notas_i in (None, '')) else int(notas_i)
            folletos.append({
                'idx': i + 1,
                'title': (f.get('title') or auto_title or f'FOLLETO {i+1}').strip(),
                'extracts': extracts,
                'notas': notas_i,
            })

        tmpdir = OUTPUT_DIR
        # --- Paso 1: digital individual de cada folleto con paginación continua ---
        # Igual al ejemplo: el ÍNDICE muestra la pág de título (sin número) = 1ra pág numerada - 1
        # Cada folleto en el tomo ocupa: separadora + 1 blanca + contenido + notas
        S = start_page - 1
        for f in folletos:
            f['idx_page'] = S
            f['start'] = S + 1  # 1ra página numerada (digital individual + tomo)
            dig_base = tmpdir / f"{uid}_f{f['idx']}_digbase.pdf"
            create_digital_pdf(f['extracts'], f['title'], logo_path, str(dig_base), margins, f['start'], title_gap=title_gap, ajustes=list(ajustes_in))
            f['content_pages'] = len(PdfReader(str(dig_base)).pages) - 2  # quita portada+blanco
            _nom = (secure_filename((f['title'] or 'estudio').strip()[:40]) or 'estudio').lower()  # v69: archivos en minusculas
            _suf = ('_f' + str(f['idx'])) if len(folletos) > 1 else ''  # v77: sufijo tambien en minusculas
            from datetime import datetime as _dt77
            _fecha77 = _dt77.now().strftime('%Y_%m_%d')
            dig_final = tmpdir / f"dig_{_fecha77}_{_nom}{_suf}.pdf"
            if f['notas'] > 0:
                append_notas_to_digital(str(dig_base), f['notas'], str(dig_final))
                os.remove(str(dig_base))
            else:
                shutil.move(str(dig_base), str(dig_final))
            f['digital_pdf'] = f"/outputs/{dig_final.name}"
            f['digital_pages'] = len(PdfReader(str(dig_final)).pages)
            foll_out = tmpdir / f"book_{_fecha77}_{_nom}{_suf}.pdf"
            create_folleto_pdf(str(dig_final), str(foll_out), use_notas=(use_notas_blanks and f['notas'] > 0))
            f['folleto_pdf'] = f"/outputs/{foll_out.name}"
            f['folleto_pages'] = len(PdfReader(str(foll_out)).pages)
            # v57: mapa de paginas para el Ajustador (nº de pagina del visor)
            _bottom_y = PAGE_H - 56.0  # limite real: la ultima linea de una pag llena llega a y1~553.5
            f['paginas_titulos'] = _scan_digital_pages(str(dig_final), f['extracts'], _bottom_y)
            S += 2 + f['content_pages'] + f['notas']  # separadora + blanca + contenido + notas

        # --- Paso 2: front matter igual al ejemplo: [blanca, blanca, portada, blanca, (prefacio, blanca), INDICE, blanca] ---
        blankA = tmpdir / f"{uid}_toma_bA.pdf"; create_blank_pdf(str(blankA), 2)
        portada = tmpdir / f"{uid}_tomo_portada.pdf"
        create_tomo_portada_pdf(tomo_title, tomo_subtitle, portada_label, logo_path, str(portada))
        blankB = tmpdir / f"{uid}_toma_bB.pdf"; create_blank_pdf(str(blankB), 1)
        pref_path = None
        pref_p = 0
        if prefacion:
            pref_path = tmpdir / f"{uid}_tomo_pref.pdf"
            create_prefacio_pdf(prefacion, str(pref_path), margins)
            pref_p = len(PdfReader(str(pref_path)).pages)
            blankC = tmpdir / f"{uid}_toma_bC.pdf"; create_blank_pdf(str(blankC), 1)
        entries = [(f['title'], f['idx_page']) for f in folletos]
        idx_path = tmpdir / f"{uid}_tomo_idx.pdf"
        create_indice_pdf(entries, str(idx_path))
        idx_p = len(PdfReader(str(idx_path)).pages)
        blankD = tmpdir / f"{uid}_toma_bD.pdf"; create_blank_pdf(str(blankD), 1)
        F = 5 + pref_p + (1 if pref_path else 0) + idx_p

        # Descarga aparte: portada + prefacio + índice (sin blancas)
        front_pdf = tmpdir / f"{uid}_TOMO_FRONT_{secure_filename(tomo_title[:24]).lower()}.pdf"
        merge_pdfs([str(portada)] + ([str(pref_path)] if pref_path else []) + [str(idx_path)], str(front_pdf))

        # --- Paso 3: armar el tomo: cada folleto = separadora + blanca + contenido + notas ---
        parts = [str(blankA), str(portada), str(blankB)]
        if pref_path:
            parts += [str(pref_path), str(blankC)]
        parts += [str(idx_path), str(blankD)]
        pos = F
        for f in folletos:
            # v76: cada folleto arranca en posicion IMPAR (recta), igual que en
            # su digital individual. Si la acumulada sale impar, una blanca de
            # guarda re-alinea (asi las margenes espejadas quedan bien).
            if pos % 2 == 1:
                _gb = tmpdir / f"{uid}_f{f['idx']}_guard.pdf"; create_blank_pdf(str(_gb), 1)
                parts.append(str(_gb)); pos += 1
            div = tmpdir / f"{uid}_f{f['idx']}_div.pdf"
            create_folleto_divisor_pdf(f['title'], str(div))
            bl = tmpdir / f"{uid}_f{f['idx']}_bl.pdf"; create_blank_pdf(str(bl), 1)
            cp = tmpdir / f"{uid}_f{f['idx']}_content.pdf"
            # v76: REUTILIZAR el PDF ya digital del folleto (paginas 3..2+n) que
            # trae TODOS los arreglos del formato folleto (margenes, reglas del
            # Ajustador, nivelar) en vez de reconstruir el contenido SIN ajustes.
            # Asi el tomo sale ajustado y solo falta el ajuste de impresion.
            import pymupdf as _pm76
            _dd = _pm76.open(str(OUTPUT_DIR / f['digital_pdf'].split('/')[-1]))
            _oo = _pm76.open()
            _oo.insert_pdf(_dd, from_page=2, to_page=1 + f['content_pages'])
            _oo.save(str(cp)); _oo.close(); _dd.close()
            n_c = len(PdfReader(str(cp)).pages)
            parts += [str(div), str(bl), str(cp)]
            pos += 2 + n_c
            if f['notas'] > 0:
                np_ = tmpdir / f"{uid}_f{f['idx']}_notas.pdf"
                create_notas_pages_pdf(f['notas'], str(np_), pagesize=(PAGE_W, PAGE_H))
                parts.append(str(np_))
                pos += f['notas']
        # Rellenar al final con blancas hasta múltiplo de 4 (como el ejemplo: 240 págs)
        pad = (4 - pos % 4) % 4
        padp = None
        if pad:
            padp = tmpdir / f"{uid}_toma_pad.pdf"
            create_blank_pdf(str(padp), pad)
            parts.append(str(padp))

        tomo_digital = tmpdir / f"{uid}_TOMO_DIGITAL_{secure_filename(tomo_title[:24]).lower()}.pdf"
        merge_pdfs(parts, str(tomo_digital))

        # limpiar tmps intermedios
        for f in folletos:
            for suf in ['_content.pdf', '_notas.pdf', '_div.pdf', '_bl.pdf']:
                pp = tmpdir / f"{uid}_f{f['idx']}{suf}"
                if pp.exists():
                    os.remove(str(pp))
        tmp_fr = [blankA, blankB, blankD, portada, idx_path] + ([pref_path, blankC] if pref_path else [])
        if padp: tmp_fr.append(padp)
        for pp in tmp_fr:
            if pp and pp.exists():
                os.remove(str(pp))

        total_p = len(PdfReader(str(tomo_digital)).pages)
        return jsonify({
            'success': True,
            'tomo_digital': f"/outputs/{tomo_digital.name}",
            'front_pdf': f"/outputs/{front_pdf.name}",
            'tomo_pages': total_p,
            'front_pages': F,
            'index': [{'label': f['title'], 'page': f['idx_page']} for f in folletos],
            'folletos': [{
                'idx': f['idx'], 'title': f['title'], 'start': f['start'], 'idx_page': f['idx_page'],
                'content_pages': f['content_pages'], 'notas': f['notas'],
                'digital_pdf': f['digital_pdf'], 'digital_pages': f['digital_pages'],
                'folleto_pdf': f['folleto_pdf'], 'folleto_pages': f['folleto_pages'],
                'paginas_titulos': f.get('paginas_titulos', {}),
            } for f in folletos],
            'message': f"TOMO {tomo_title}: {len(folletos)} folletos • {total_p} págs digital (front {F}p) • 1ra pág numerada {start_page} (índice {start_page-1}) • índice OK • ⚠ revisa: el motor detectó {sum(len(f['extracts']) for f in folletos)} títulos (si tu libro tiene más extractos reales, escribe ---T--- delante del título dudoso)"
        })
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({'error': str(e)}), 500


def _update_url():
    try:
        u = (Path(__file__).resolve().parent / 'update_url.txt').read_text(encoding='utf-8').strip()
    except Exception:
        return None
    if not u or 'PON_AQUI' in u:
        return None
    return u

@app.route('/api/update/check')
def api_update_check():
    """v81: busca en la nube si hay version nueva (necesita internet)."""
    import urllib.request as _ur
    url = _update_url()
    if not url:
        return jsonify({'configurado': False, 'actual': VERSION})
    try:
        with _ur.urlopen(url, timeout=6) as _r:
            man = json.loads(_r.read().decode('utf-8'))
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({'configurado': True, 'online': False, 'actual': VERSION, 'detalle': str(e)})
    nueva = str(man.get('version', '')).strip()
    def _vn(v):
        m = ''.join(ch for ch in (v or '') if ch.isdigit())
        return int(m) if m else 0
    return jsonify({'configurado': True, 'online': True, 'actual': VERSION,
                    'nueva': nueva, 'hay_nueva': _vn(nueva) > _vn(VERSION),
                    'zip': man.get('zip', ''), 'notas': man.get('notas', '')})

@app.route('/api/update/install', methods=['POST'])
def api_update_install():
    """v81: descarga el paquete nuevo y prepara ACTUALIZAR.bat (el cambio
    se completa al cerrar la app y abrir ACTUALIZAR.bat)."""
    import urllib.request as _ur, zipfile as _zf
    try:
        datos = request.get_json(force=True) or {}
    except Exception:
        datos = {}
    zurl = (datos.get('zip') or '').strip()
    if not zurl.startswith('http://') and not zurl.startswith('https://'):
        return jsonify({'error': 'Direccion de descarga no valida'}), 400
    base = Path(__file__).resolve().parent
    updir = base / 'updates'
    updir.mkdir(exist_ok=True)
    dst = updir / 'paquete.zip'
    try:
        with _ur.urlopen(zurl, timeout=120) as r, open(dst, 'wb') as f:
            while True:
                ch = r.read(65536)
                if not ch:
                    break
                f.write(ch)
    except Exception as e:
        return jsonify({'error': f'No se pudo descargar: {e}'}), 502
    if not _zf.is_zipfile(dst):
        return jsonify({'error': 'El archivo bajado no es un zip valido'}), 400
    nuevo = updir / 'nuevo'
    if nuevo.exists():
        shutil.rmtree(nuevo)
    nuevo.mkdir()
    with _zf.ZipFile(dst) as z:
        for m in z.namelist():
            t = os.path.normpath(m)
            if t.startswith('..') or os.path.isabs(t):
                return jsonify({'error': 'Zip invalido'}), 400
        z.extractall(nuevo)
    bat = base / 'ACTUALIZAR.bat'
    bat.write_text(
        "@echo off\r\ncd /d \"%~dp0\"\r\n"
        "echo ==========================================================\r\n"
        "echo  ACTUALIZANDO LA APP A LA VERSION NUEVA\r\n"
        "echo  IMPORTANTE: cierra la ventana de la app (ejecutar.bat)\r\n"
        "echo  antes de continuar si sigue abierta.\r\n"
        "echo ==========================================================\r\n"
        "timeout /t 3 >nul\r\n"
        "xcopy /e /y /i \"updates\\nuevo\\app\" \".\"\r\n"
        "rmdir /s /q \"updates\"\"\r\n"
        "del \"%~f0\"\r\n"
        "echo LISTO. Abre de nuevo ejecutar.bat\r\n"
        "pause\r\n", encoding='utf-8')
    # v81: NO se borra updates/nuevo: es lo que copia ACTUALIZAR.bat.
    # (el propio ACTUALIZAR.bat borra la carpeta updates al terminar)
    return jsonify({'listo': True, 'msg': 'Paquete descargado y preparado. Cierra la app y abre ACTUALIZAR.bat (queda en la carpeta de la app).'})

@app.route('/')
def index():
    r = make_response(render_template('index.html'))
    r.headers['Cache-Control'] = 'no-store, max-age=0'
    return r

@app.route('/api/sample_text')
def sample_text():
    try:
        # Buscar el txt de prueba
        for p in [BASE_DIR / 'uploads', Path('/home/user/uploads')]:
            if p.exists():
                for f in p.glob('*.txt'):
                    try:
                        txt = f.read_text(encoding='utf-8', errors='ignore')[:10000]
                        return jsonify({'text': txt, 'file': str(f)})
                    except:
                        continue
        return jsonify({'text': ''})
    except Exception as e:
        return jsonify({'text': '', 'error': str(e)})

@app.route('/api/extract_text', methods=['POST'])
def extract_text():
    try:
        if 'docx_file' not in request.files:
            return jsonify({'error': 'No file'}), 400
        file = request.files['docx_file']
        uid = uuid.uuid4().hex[:8]
        filename = f"{uid}_{secure_filename(file.filename)}"
        file_path = UPLOAD_DIR / filename
        file.save(str(file_path))
        ext = Path(file.filename).suffix.lower()
        if ext == '.txt':
            text = Path(file_path).read_text(encoding='utf-8', errors='ignore')
        else:
            doc = Document(str(file_path))
            text = "\n".join([p.text for p in doc.paragraphs])
        return jsonify({'text': text[:50000]})
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/convert_text', methods=['POST'])
def convert_text():
    try:
        # Aceptar JSON (igual que /api/tomo, que funciona en todas las PCs) o formulario
        _j = request.get_json(silent=True) if request.is_json else None
        def _val(_k, _def=''):
            return _j.get(_k, _def) if _j is not None else request.form.get(_k, _def)
        raw_text = (_val('raw_text','') or '').strip()
        if not raw_text:
            return jsonify({'error': 'Texto vacío'}), 400
        title = (_val('title','') or '').strip() or "EL TÍTULO DE PROPIEDAD EN LA TIERRA"
        try:
            start_page = int(_val('start_page','164'))
        except:
            start_page = 164

        # Guardar raw_text temporal y parsear
        uid = uuid.uuid4().hex[:8]
        tmp_txt = OUTPUT_DIR / f"{uid}_raw.txt"
        tmp_txt.write_text(raw_text, encoding='utf-8')
        extracts, detected_title = parse_txt_advanced(str(tmp_txt))
        try:
            os.remove(str(tmp_txt))
        except Exception:
            pass
        # Si no detecta extractos, tratar todo como un solo extracto
        if not extracts:
            extracts = [{'title_lines':[], 'subtitle':None,'author':'','date':'','city':'','body': raw_text}]
        if not (_val('title','') or '').strip() and detected_title:
            title = detected_title

        margins = DEFAULT_MARGINS

        logo_path = None
        if _j is None and 'logo_file' in request.files:
            lf = request.files['logo_file']
            if lf and lf.filename != '':
                lext = Path(lf.filename).suffix.lower()
                if lext in ALLOWED_IMG:
                    lname = f"{uid}_logo_{secure_filename(lf.filename)}"
                    logo_path = UPLOAD_DIR / lname
                    lf.save(str(logo_path))
                    logo_path = str(logo_path)

        # Parámetros de notas
        try:
            num_notas = int(_val('num_notas','0'))
        except:
            num_notas = 0
        # Renglón antes de títulos ajustable (en renglones; mínimo 1 = 18pt)
        try:
            _tgl = float(_val('title_gap_lines','1'))
        except Exception:
            _tgl = 1.0
        title_gap = max(1.0, _tgl) * 18.0
        use_notas_for_blanks = (_val('use_notas_for_blanks','1') in ('1', True, 'true'))
        # Ajuste notas: si dice 0 notas NO poner NOTAS al final ni en padding - dejar hoja en blanco
        if num_notas <= 0:
            use_notas_for_blanks = False

        import time as _tm
        _t0 = _tm.time()
        print(f"[CONVERT] {len(extracts)} extractos recibidos, generando...", flush=True)

        # Digital base sin notas
        digital_base_filename = f"{uid}_DigBase_{secure_filename(title[:30]).lower()}.pdf"
        digital_base_path = OUTPUT_DIR / digital_base_filename
        create_digital_pdf(extracts, title, logo_path, str(digital_base_path), margins, start_page, title_gap=title_gap)
        print(f"[CONVERT] digital listo en {_tm.time()-_t0:.2f}s", flush=True)

        # Añadir páginas de NOTAS configurables al final del digital
        if num_notas > 0:
            digital_filename = f"{uid}_Dig_{secure_filename(title[:30]).lower()}.pdf"
            digital_path = OUTPUT_DIR / digital_filename
            append_notas_to_digital(str(digital_base_path), num_notas, str(digital_path))
            try:
                os.remove(str(digital_base_path))
            except:
                pass
        else:
            # SIN shutil.move (igual que el tomo): el mismo archivo sirve como final
            digital_filename = digital_base_filename
            digital_path = digital_base_path

        folleto_filename = f"{uid}_FOLLETO_{secure_filename(title[:30]).lower()}.pdf"
        folleto_path = OUTPUT_DIR / folleto_filename
        create_folleto_pdf(str(digital_path), str(folleto_path), use_notas=use_notas_for_blanks)
        _ttot = _tm.time() - _t0
        print(f"[CONVERT] folleto listo en {_ttot:.2f}s - OK", flush=True)

        dig_pages = len(PdfReader(str(digital_path)).pages)
        foll_pages = len(PdfReader(str(folleto_path)).pages)
        return jsonify({
            'success': True,
            'title': title,
            'digital_pdf': f"/outputs/{digital_filename}",
            'folleto_pdf': f"/outputs/{folleto_filename}",
            'pages': dig_pages,
            'folleto_pages': foll_pages,
            'extracts': len(extracts),
            'message': f'{len(extracts)} extractos • DIGITAL {dig_pages} págs (desde {start_page}) + {num_notas} notas • FOLLETO {foll_pages}h sin blancos • Notas {"ON" if use_notas_for_blanks else "OFF"} • {_ttot:.1f}s'
        })
    except Exception as e:
        import traceback; traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/editor')
def editor():
    r = make_response(render_template('editor.html'))
    r.headers['Cache-Control'] = 'no-store, max-age=0'
    return r

@app.route('/api/convert_manual', methods=['POST'])
def convert_manual():
    try:
        import json
        title = request.form.get('title','').strip() or "EL TÍTULO DE PROPIEDAD EN LA TIERRA"
        extracts_json = request.form.get('extracts_json','[]')
        try:
            extracts_raw = json.loads(extracts_json)
        except:
            extracts_raw = []

        # Convert extracts_raw to our internal format, handling [[B]] markers for bold
        extracts = []
        for er in extracts_raw:
            # Body may contain [[B]]...[[/B]] markers -> convert to uppercase bold logic
            # For our PDF generator, format_body_with_bold will detect uppercase, but we also support <b> via [[B]]
            body = er.get('body','')
            # Convert [[B]] markers to actual uppercase (already uppercase) and keep for bold detection
            # Replace [[B]] and [[/B]] with just the inner text (already uppercase) - format_body_with_bold will make it bold
            body = body.replace('[[B]]','').replace('[[/B]]','')
            extracts.append({
                'title_lines': er.get('title_lines', []),
                'subtitle': er.get('subtitle',''),
                'author': er.get('author',''),
                'date': er.get('date',''),
                'city': er.get('city',''),
                'body': body
            })

        try:
            m_top = float(request.form.get('margin_top', DEFAULT_MARGINS['top']))
            m_bottom = float(request.form.get('margin_bottom', DEFAULT_MARGINS['bottom']))
            m_inner = float(request.form.get('margin_inner', DEFAULT_MARGINS['inner']))
            m_outer = float(request.form.get('margin_outer', DEFAULT_MARGINS['outer']))
            start_page = int(request.form.get('start_page','164'))
        except:
            m_top = DEFAULT_MARGINS['top']
            m_bottom = DEFAULT_MARGINS['bottom']
            m_inner = DEFAULT_MARGINS['inner']
            m_outer = DEFAULT_MARGINS['outer']
            start_page = 164

        margins = {'top': m_top, 'bottom': m_bottom, 'inner': m_inner, 'outer': m_outer}

        logo_path = None
        if 'logo_file' in request.files:
            lf = request.files['logo_file']
            if lf and lf.filename != '':
                lext = Path(lf.filename).suffix.lower()
                if lext in ALLOWED_IMG:
                    uid = uuid.uuid4().hex[:8]
                    lname = f"{uid}_logo_{secure_filename(lf.filename)}"
                    logo_path = UPLOAD_DIR / lname
                    lf.save(str(logo_path))
                    logo_path = str(logo_path)

        try:
            num_notas = int(request.form.get('num_notas','0'))
        except:
            num_notas = 0
        # Renglón antes de títulos ajustable (en renglones; mínimo 1 = 18pt)
        try:
            _tgl = float(request.form.get('title_gap_lines','1'))
        except Exception:
            _tgl = 1.0
        title_gap = max(1.0, _tgl) * 18.0
        use_notas_for_blanks = request.form.get('use_notas_for_blanks','1') == '1'
        # Ajuste notas: si dice 0 notas NO poner NOTAS al final ni en padding - dejar hoja en blanco
        if num_notas <= 0:
            use_notas_for_blanks = False

        uid = uuid.uuid4().hex[:8]
        digital_base_filename = f"{uid}_DigBase_{secure_filename(title[:30]).lower()}.pdf"
        digital_base_path = OUTPUT_DIR / digital_base_filename
        create_digital_pdf(extracts, title, logo_path, str(digital_base_path), margins, start_page, title_gap=title_gap)

        digital_filename = f"{uid}_Dig_{secure_filename(title[:30]).lower()}.pdf"
        digital_path = OUTPUT_DIR / digital_filename
        if num_notas > 0:
            append_notas_to_digital(str(digital_base_path), num_notas, str(digital_path))
            try:
                os.remove(str(digital_base_path))
            except:
                pass
        else:
            if str(digital_base_path) != str(digital_path):
                shutil.move(str(digital_base_path), str(digital_path))

        folleto_filename = f"{uid}_FOLLETO_{secure_filename(title[:30]).lower()}.pdf"
        folleto_path = OUTPUT_DIR / folleto_filename
        create_folleto_pdf(str(digital_path), str(folleto_path), use_notas=use_notas_for_blanks)

        dig_pages = len(PdfReader(str(digital_path)).pages)
        foll_pages = len(PdfReader(str(folleto_path)).pages)
        return jsonify({
            'success': True,
            'title': title,
            'digital_pdf': f"/outputs/{digital_filename}",
            'folleto_pdf': f"/outputs/{folleto_filename}",
            'pages': dig_pages,
            'folleto_pages': foll_pages,
            'extracts': len(extracts),
            'message': f'{len(extracts)} extractos • DIGITAL {dig_pages} págs + {num_notas} notas • FOLLETO {foll_pages}h sin blancos • Notas {"ON" if use_notas_for_blanks else "OFF"}'
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/convert', methods=['POST'])
def convert():
    try:
        title = request.form.get('title','').strip()
        if not title:
            title = "EL TÍTULO DE PROPIEDAD EN LA TIERRA"

        try:
            m_top = float(request.form.get('margin_top', DEFAULT_MARGINS['top']))
            m_bottom = float(request.form.get('margin_bottom', DEFAULT_MARGINS['bottom']))
            m_inner = float(request.form.get('margin_inner', DEFAULT_MARGINS['inner']))
            m_outer = float(request.form.get('margin_outer', DEFAULT_MARGINS['outer']))
            start_page = int(request.form.get('start_page', '164'))
        except:
            m_top = DEFAULT_MARGINS['top']
            m_bottom = DEFAULT_MARGINS['bottom']
            m_inner = DEFAULT_MARGINS['inner']
            m_outer = DEFAULT_MARGINS['outer']
            start_page = 164

        margins = {'top': m_top, 'bottom': m_bottom, 'inner': m_inner, 'outer': m_outer}

        if 'docx_file' not in request.files:
            return jsonify({'error':'No se subió archivo'}),400
        file = request.files['docx_file']
        if file.filename == '':
            return jsonify({'error':'Archivo vacío'}),400
        ext = Path(file.filename).suffix.lower()
        if ext not in ALLOWED_DOC:
            return jsonify({'error':f'Formato {ext} no permitido, use .docx o .txt'}),400

        uid = uuid.uuid4().hex[:8]
        filename = f"{uid}_{secure_filename(file.filename)}"
        file_path = UPLOAD_DIR / filename
        file.save(str(file_path))

        logo_path = None
        if 'logo_file' in request.files:
            lf = request.files['logo_file']
            if lf and lf.filename != '':
                lext = Path(lf.filename).suffix.lower()
                if lext in ALLOWED_IMG:
                    lname = f"{uid}_logo_{secure_filename(lf.filename)}"
                    logo_path = UPLOAD_DIR / lname
                    lf.save(str(logo_path))
                    logo_path = str(logo_path)

        extracts, detected_title = parse_any_file(str(file_path))
        if not request.form.get('title','').strip() and detected_title:
            title = detected_title

        try:
            num_notas = int(request.form.get('num_notas','0'))
        except:
            num_notas = 0
        # Renglón antes de títulos ajustable (en renglones; mínimo 1 = 18pt)
        try:
            _tgl = float(request.form.get('title_gap_lines','1'))
        except Exception:
            _tgl = 1.0
        title_gap = max(1.0, _tgl) * 18.0
        use_notas_for_blanks = request.form.get('use_notas_for_blanks','1') == '1'
        # Ajuste notas: si dice 0 notas NO poner NOTAS al final ni en padding - dejar hoja en blanco
        if num_notas <= 0:
            use_notas_for_blanks = False

        digital_base_filename = f"{uid}_DigBase_{secure_filename(title[:30]).lower()}.pdf"
        digital_base_path = OUTPUT_DIR / digital_base_filename
        create_digital_pdf(extracts, title, logo_path, str(digital_base_path), margins, start_page, title_gap=title_gap)

        digital_filename = f"{uid}_Dig_{secure_filename(title[:30]).lower()}.pdf"
        digital_path = OUTPUT_DIR / digital_filename
        if num_notas > 0:
            append_notas_to_digital(str(digital_base_path), num_notas, str(digital_path))
            try:
                os.remove(str(digital_base_path))
            except:
                pass
        else:
            if str(digital_base_path) != str(digital_path):
                shutil.move(str(digital_base_path), str(digital_path))

        folleto_filename = f"{uid}_FOLLETO_{secure_filename(title[:30]).lower()}.pdf"
        folleto_path = OUTPUT_DIR / folleto_filename
        create_folleto_pdf(str(digital_path), str(folleto_path), use_notas=use_notas_for_blanks)

        dig_pages = len(PdfReader(str(digital_path)).pages)
        foll_pages = len(PdfReader(str(folleto_path)).pages)
        return jsonify({
            'success': True,
            'title': title,
            'digital_pdf': f"/outputs/{digital_filename}",
            'folleto_pdf': f"/outputs/{folleto_filename}",
            'pages': dig_pages,
            'folleto_pages': foll_pages,
            'extracts': len(extracts),
            'message': f'{len(extracts)} extractos • DIGITAL {dig_pages} págs + {num_notas} notas • FOLLETO {foll_pages}h sin blancos • Notas {"ON" if use_notas_for_blanks else "OFF"}'
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

def _run_gen(nombre, fn, timeout=60):
    """Ejecuta un paso de generacion con VIGILANTE de tiempo.
    Si un paso se cuelga (antivirus, carpeta sincronizada Box/OneDrive, disco...),
    devuelve un error CLARO nombrando el paso, en vez de dejar la app dando vueltas."""
    import time as _t
    import concurrent.futures as _cf
    t0 = _t.time()
    print(f"[GEN] {nombre}: iniciando...", flush=True)
    ex = _cf.ThreadPoolExecutor(max_workers=1)
    try:
        out = ex.submit(fn).result(timeout=timeout)
    except _cf.TimeoutExpired:
        print(f"[GEN] {nombre}: TIMEOUT >{timeout}s  <<< ESTE PASO SE CUELGA EN ESTA PC", flush=True)
        try: ex.shutdown(wait=False)
        except Exception: pass
        raise RuntimeError(f'PASO {nombre}: tardo mas de {timeout}s y fue CANCELADO (mira la ventana negra). Causas tipicas: antivirus escaneando python.exe, o la carpeta de la app esta sincronizada por Box/OneDrive (mueve la app a C:\\LP36\\ fuera de carpetas sincronizadas).')
    except Exception:
        raise
    print(f"[GEN] {nombre}: OK en {_t.time()-t0:.2f}s", flush=True)
    try: ex.shutdown(wait=False)
    except Exception: pass
    return out

@app.route('/api/ping')
def api_ping():
    """Diagnóstico: si responde, el servidor está vivo. /api/ping en el navegador debe mostrar JSON."""
    return jsonify({'ok': True, 'version': VERSION, 'msg': 'servidor funcionando'})

@app.route('/api/selftest')
def api_selftest():
    """DIAGNOSTICO: prueba cada paso de la generacion por separado y devuelve tiempos.
    Abre http://127.0.0.1:PUERTO/api/selftest en el navegador. Si se cuelga, la
    ventana negra muestra el ultimo paso [SELFTEST] iniciado = el paso del problema."""
    import time as _t, traceback as _tb
    steps = []
    out = {'ok': True, 'version': VERSION, 'steps': steps}
    try:
        uid = uuid.uuid4().hex[:8]
        t0 = _t.time()
        print("[SELFTEST] 1/5 parseando texto de prueba...", flush=True)
        txt_demo = ("PRUEBA DE DIAGNOSTICO\n\nEste es un parrafo de prueba para el diagnostico del sistema. " * 40)
        tmp = OUTPUT_DIR / f"{uid}_self.txt"
        tmp.write_text(txt_demo, encoding='utf-8')
        extracts, btitle = parse_txt_advanced(str(tmp))
        steps.append(['parse', round(_t.time()-t0, 3), f"{len(extracts)} extractos"])

        print("[SELFTEST] 2/5 generando DIGITAL...", flush=True)
        t1 = _t.time()
        dig = OUTPUT_DIR / f"{uid}_self_dig.pdf"
        create_digital_pdf(extracts, 'PRUEBA', None, str(dig), {}, 1)
        steps.append(['digital', round(_t.time()-t1, 3), f"{len(PdfReader(str(dig)).pages)} pags"])

        print("[SELFTEST] 3/5 agregando NOTAS...", flush=True)
        t2 = _t.time()
        dig2 = OUTPUT_DIR / f"{uid}_self_dig_notas.pdf"
        append_notas_to_digital(str(dig), 1, str(dig2))
        steps.append(['notas', round(_t.time()-t2, 3), 'ok'])

        print("[SELFTEST] 4/5 generando FOLLETO (pymupdf o fallback)...", flush=True)
        t3 = _t.time()
        fol = OUTPUT_DIR / f"{uid}_self_fol.pdf"
        create_folleto_pdf(str(dig2), str(fol), use_notas=False)
        steps.append(['folleto', round(_t.time()-t3, 3), f"{len(PdfReader(str(fol)).pages)} hojas"])

        print("[SELFTEST] 5/5 verificando archivos...", flush=True)
        for f in (dig, dig2, fol, tmp):
            try: f.unlink()
            except Exception: pass
        steps.append(['TOTAL', round(_t.time()-t0, 3), 'OK'])
        out['msg'] = 'AUTOTEST COMPLETO SIN ERRORES - el motor funciona'
        print("[SELFTEST] COMPLETO OK", flush=True)
    except Exception as e:
        out['ok'] = False
        out['error'] = str(e)
        out['trace'] = _tb.format_exc()
        steps.append(['ERROR', 0, str(e)])
        print(f"[SELFTEST] ERROR: {e}", flush=True)
    return jsonify(out)

@app.route('/api/cerrar', methods=['POST'])
def api_cerrar():
    # Apaga la aplicacion de verdad: el servidor se detiene y la ventana negra
    # queda lista para cerrarse. Para volver a usar la app: ejecutar.bat
    import threading as _threading
    def _morir():
        import time as _t, os as _o, signal as _s
        _t.sleep(0.8)
        try:
            _o.kill(_o.getpid(), _s.SIGTERM)
        except Exception:
            _o._exit(1)
    _threading.Thread(target=_morir, daemon=True).start()
    return jsonify(ok=True, msg='Cerrando la aplicacion...')

@app.route('/outputs/<path:filename>')
def download_output(filename):
    return send_from_directory(str(OUTPUT_DIR), filename, as_attachment=False)

@app.route('/uploads/<path:filename>')
def download_upload(filename):
    return send_from_directory(str(UPLOAD_DIR), filename, as_attachment=False)

if __name__ == '__main__':
    import sys as _sys, socket as _socket, webbrowser as _wb, threading as _th
    # Elegir el PRIMER puerto LIBRE. Si una instancia vieja u otro programa ocupa
    # el 5000, la app NO se queda bloqueada: pasa automáticamente al siguiente
    # puerto y abre el navegador ahí. (Elimina el problema de la instancia vieja
    # congelada que deja la app "generando" para siempre.)
    _port = None
    for _p in (5000, 5050, 5051, 5052, 5053):
        _chk = _socket.socket()
        try:
            _chk.bind(('0.0.0.0', _p))
            _port = _p
        except OSError:
            print(f"Puerto {_p} ocupado, probando el siguiente...", flush=True)
        finally:
            _chk.close()
        if _port is not None:
            break
    if _port is None:
        print('No hay puertos libres (5000, 5050-5053).')
        print('Cierra TODAS las ventanas negras de la app y vuelve a ejecutar ejecutar.bat')
        try:
            input('Presiona ENTER para cerrar esta ventana...')
        except Exception:
            pass
        _sys.exit(1)
    # 2) Windows: desactivar QuickEdit de la consola (un clic pausa toda la app)
    if _sys.platform == 'win32':
        try:
            import ctypes
            _k32 = ctypes.windll.kernel32
            _h = _k32.GetStdHandle(-10)  # STD_INPUT_HANDLE
            _mode = ctypes.c_uint32()
            if _k32.GetConsoleMode(_h, ctypes.byref(_mode)):
                _k32.SetConsoleMode(_h, (_mode.value & ~0x0040) | 0x0080)
        except Exception:
            pass
    # 3) Abrir el navegador cuando el servidor esté arriba (UNA sola vez)
    def _abrir():
        try:
            _wb.open(f'http://127.0.0.1:{_port}')
        except Exception:
            pass
    _th.Timer(1.5, _abrir).start()
    print()
    print('=' * 62)
    print(f'  APP LIBRO PDF {VERSION} lista en:')
    print()
    print(f'      http://127.0.0.1:{_port}')
    print()
    print('  El navegador se abre solo en unos segundos.')
    print('  Si no abre: copia esa direccion en tu navegador.')
    print('  NO hagas clic dentro de esta ventana. Para salir: Ctrl+C')
    print('=' * 62)
    # 4) SIN reloader: un solo proceso python. (El reloader crea 2 procesos y los
    #    huérfanos son los que dejan el puerto ocupado y la app "congelada")
    app.run(host='0.0.0.0', port=_port, debug=True, use_reloader=False)
