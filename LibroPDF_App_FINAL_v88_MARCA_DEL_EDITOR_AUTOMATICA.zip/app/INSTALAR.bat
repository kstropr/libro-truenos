@echo off
cd /d "%~dp0"
echo ==========================================================
echo  INSTALACION UNICA - Editor de libros de los Truenos v88
echo  (solo se hace UNA vez por computadora, necesita internet)
echo ==========================================================
echo.
where python >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python no esta instalado o no esta en el PATH.
    echo Instala Python desde https://www.python.org/downloads/
    echo y MARCA la casilla "Add python.exe to PATH" antes de Install Now.
    pause
    exit /b 1
)
echo Instalando librerias (Flask, ReportLab, PyPDF2, PyMuPDF, python-docx, Pillow)...
python -m pip install Flask==3.0.3 reportlab==4.2.0 PyPDF2==3.0.1 pymupdf python-docx Pillow
if errorlevel 1 (
    echo Reintentando con el lanzador py...
    py -m pip install Flask==3.0.3 reportlab==4.2.0 PyPDF2==3.0.1 pymupdf python-docx Pillow
)
echo Verificando que todo quedo bien instalado...
python -c "import flask, reportlab, PyPDF2, fitz, docx, PIL; print('VERIFICACION OK: todo listo')"
if errorlevel 1 py -c "import flask, reportlab, PyPDF2, fitz, docx, PIL; print('VERIFICACION OK: todo listo')"
echo.
echo ==========================================================
echo  LISTO. Si no viste errores, cierra esta ventana y usa
echo  siempre ejecutar.bat para abrir la aplicacion.
echo ==========================================================
pause
