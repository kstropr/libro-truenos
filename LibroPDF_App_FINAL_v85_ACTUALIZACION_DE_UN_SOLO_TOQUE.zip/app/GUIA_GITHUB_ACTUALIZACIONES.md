# 🔄 CÓMO ACTUALIZAR LA APP DESDE LA NUBE (GitHub) — Guía paso a paso

Con esto, la app misma te avisa cuando hay una versión nueva y la instala
con un clic. Solo necesitas internet en la PC en ese momento.

## PARTE 1 — Crear tu cuenta y repositorio (UNA sola vez)

1. Entra a **https://github.com** y toca **Sign up** (crear cuenta).
   - Usa tu correo y una contraseña. Guarda esos datos.
2. Una vez dentro, toca el **+** (arriba a la derecha) → **New repository**.
   - Name: `libro-truenos` (escríbelo igual)
   - Marca **Public** (público). NO marques nada más.
   - Toca **Create repository**.

## PARTE 2 — Subir el paquete de la versión

1. En tu repositorio, toca **Add file → Create new file**.
   - En el nombre escribe: `version.json`
   - En el contenido grande pega EXACTAMENTE esto (cambia solo lo que se pide):

```json
{
  "version": "v81",
  "zip": "https://raw.githubusercontent.com/kstropr/libro-truenos/main/LibroPDF_App_FINAL_v85_ACTUALIZACION_DE_UN_SOLO_TOQUE.zip",
  "notas": "AQUI ESCRIBES LO QUE TRAE LA VERSION (es el texto que la gente ve al actualizarse)"
}
```

   - **kstropr** = tu nombre de usuario de GitHub.
   - Toca **Commit changes** (guardar).
2. Ahora toca **Add file → Upload files** y arrastra DOS archivos:
   `LibroPDF_App_FINAL_v85_ACTUALIZACION_DE_UN_SOLO_TOQUE.zip`
   y el archivo `version.json` (te lo entrego listo, no tienes
   que escribir nada). Toca **Commit changes**.

## PARTE 3 — Darle la dirección a la app

1. Abre el archivo `version.json` en GitHub (tócalo en la lista) y toca el
   botón **Raw**. Copia la dirección de arriba del navegador
   (se ve así: `https://raw.githubusercontent.com/kstropr/libro-truenos/main/version.json`).
2. En la carpeta de la app, abre con el **Bloc de notas** el archivo
   `update_url.txt`, borra lo que tiene, pega la dirección y guarda.

## PARTE 4 — Uso diario

- Cada vez que abras la app **con internet**, ella sola busca si hay
  versión nueva. Si la hay: aparece **"✓ Versión nueva (tienes …)"**
  en la barra de arriba; tocas, descargas, cierras la app y abres
  **ACTUALIZAR.bat**. Listo, queda actualizada.

## SUBIR UNA VERSIÓN NUEVA MÁS ADELANTE (resumen)

1. Sube el zip nuevo con **Add file → Upload files** (pisa el anterior, dale Commit).
2. Edita `version.json` (lápiz ✏) y cambia el número de versión, el
   nombre del zip y escribe en "notas" LO QUE TRAE la versión
   (ese texto es el resumen que la app muestra al terminar de
   actualizarse). Commit.
3. En la PC, toca 🔄 Actualizar → la app hace el resto.

> Si la PC no tiene internet, la app lo dice y no intenta nada: no se daña nada.
