# 📚 INSTALACIÓN – App Convertidora Word/Txt a Libro PDF
### Versión Final con Editor Manual

---

## ✅ Requisitos
- Computadora Windows 10/11, Mac o Linux
- Python 3.9 o superior (recomendado 3.11)
- 100 MB de espacio libre

---

## 🔽 PASO 1: Descargar el programa

1. Descarga toda la carpeta `app` que te entregué
2. Si te la envié como ZIP, descomprímela en:
   - Windows: `C:\LibroPDF\`
   - Mac/Linux: `~/LibroPDF/`

Deberías ver estos archivos dentro:
```
app/
├── app.py
├── requirements.txt
├── templates/
│   ├── index.html
│   └── editor.html
├── uploads/ (carpeta vacía)
└── outputs/ (carpeta vacía)
```

---

## 🐍 PASO 2: Instalar Python (si no lo tienes)

### Windows:
1. Ve a https://www.python.org/downloads/
2. Descarga Python 3.11 o 3.12
3. **MUY IMPORTANTE:** Al instalar, marca la casilla ✅ **"Add python.exe to PATH"**
4. Clic en "Install Now"

Verifica que se instaló:
- Abre CMD (tecla Windows + R, escribe `cmd`, Enter)
- Escribe: `python --version` → debe mostrar Python 3.x

### Mac:
1. Python ya viene instalado, verifica en Terminal: `python3 --version`
2. Si no, instala desde https://www.python.org o con `brew install python3`

### Linux (Ubuntu/Debian):
```bash
sudo apt update
sudo apt install python3 python3-pip
```

---

## 📦 PASO 3: Instalar librerías necesarias

### Windows:
1. Abre CMD en la carpeta del programa:
   - Ve a la carpeta `app`, en la barra de direcciones escribe `cmd` y presiona Enter
2. Escribe:
```bash
pip install -r requirements.txt
```
Si da error, prueba:
```bash
python -m pip install -r requirements.txt
```

### Mac/Linux:
Abre Terminal en la carpeta `app` y escribe:
```bash
pip3 install -r requirements.txt
```

**Librerías que se instalarán:**
- Flask (servidor web)
- python-docx (leer Word)
- reportlab (crear PDFs profesionales)
- PyPDF2 (hacer folleto booklet)
- Pillow (logos)
- PyMuPDF (opcional, para previews)

---

## ▶️ PASO 4: Ejecutar la App

### Windows (CMD):
```bash
python app.py
```
o
```bash
python3 app.py
```

### Mac/Linux (Terminal):
```bash
python3 app.py
```

Verás esto:
```
 * Running on all addresses (0.0.0.0)
 * Running on http://127.0.0.1:5000
```

### Abrir en navegador:
1. Abre Chrome, Edge o Firefox
2. Ve a: **http://localhost:5000** o **http://127.0.0.1:5000**
3. ¡Ya está tu app!

**No cierres la ventana negra (CMD/Terminal) mientras uses la app.**

---

## 📝 PASO 5: Cómo usar

### Convertidor Automático (http://localhost:5000/):
1. Escribe **Título del Libro**: `EL TÍTULO DE PROPIEDAD EN LA TIERRA`
2. **Archivo**: Arrastra tu `.docx` o `.txt` crudo
3. **Logo** (opcional): sube PNG/JPG
4. **Página inicial**: 164 (o 1)
5. Clic **Generar Libro** → Descarga 2 PDFs:
   - **Digital 5.5x8.5"** – para celular
   - **Folleto 11x8.5"** – para imprimir doble cara y doblar

### Editor Manual (http://localhost:5000/editor):
1. Clic en **"Ir a Editor Manual"**
2. Escribe cada extracto:
   - **Título**: `FIELES ADMINISTRADORES...` → botón **MAYÚSCULAS**
   - **Subtítulo**: `(Reunión de Ministros)`
   - **Autor**: `Dr. William Soto Santiago`
   - **Fecha**: `Miércoles, 10 de noviembre de 2004`
   - **Ciudad**: `Santiago de Chile, Chile`
   - **Cuerpo**: Escribe texto, selecciona frase importante → **𝐁 Negrita MAYÚSCULAS**
3. **Agregar a la lista**
4. Repite para todos los extractos
5. **Generar Libro PDF**

---

## 🖨️ Cómo imprimir el Folleto

1. Abre el PDF `Foll_...pdf` (11x8.5")
2. En impresora, selecciona **Doble cara / A dos caras / Duplex**
3. **Voltear por borde corto**
4. Imprime
5. Dobla a la mitad por el centro
6. Grapas en el lomo

¡Queda como librito!

---

## ❓ Problemas comunes

**"python no se reconoce":**
- Reinstala Python marcando "Add to PATH"
- O usa `py app.py` en vez de `python app.py`

**"pip no se reconoce":**
```bash
python -m pip install -r requirements.txt
```

**"Puerto 5000 en uso":**
- Cierra otras apps o cambia puerto en `app.py` última línea: `app.run(port=5001)`

**Antivirus bloquea:**
- Agrega excepción para la carpeta `app`

**No carga logo:**
- Usa PNG o JPG menor a 2MB

---

## 📂 Estructura final de archivos generados

```
outputs/
├── 20231123_Dig_EL_TITULO...pdf (Digital)
└── 20231123_Foll_EL_TITULO...pdf (Folleto)
```

---

## 🔄 Actualizar el programa

Si te envío nueva versión, solo reemplaza `app.py` y `templates/` y vuelve a ejecutar.

---

## 💾 Guardar tu trabajo en Editor Manual

- **Guardar JSON**: Guarda todos los extractos en un archivo `.json`
- **Cargar JSON**: Recupera trabajo anterior

---

## 📞 Soporte

Si algo no funciona, envíame:
1. Captura del error en CMD
2. Qué archivo subiste
3. Sistema operativo (Windows/Mac)

¡Listo para crear libros!
