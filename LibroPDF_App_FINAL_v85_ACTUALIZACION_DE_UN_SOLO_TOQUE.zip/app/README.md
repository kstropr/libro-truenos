# 📚 App Convertidora Word → Libro PDF – Formato Americano

Convierte cualquier archivo Word (.docx) en **dos formatos profesionales de libro** idénticos a tus ejemplos "UNÁNIMES JUNTOS":

## Formatos Generados

### 1. 📖 Digital – `Dig.TITULO.pdf`
- Tamaño: **5.5" x 8.5"** (Half Letter) – estándar americano KDP
- Lectura completa, vertical
- Ideal para: lectura en celular, tablet, enviar por WhatsApp

### 2. 📑 Folleto – `Foll.TITULO.pdf`
- Tamaño: **11" x 8.5"** apaisado (2 páginas lógicas por cara)
- Imposición tipo booklet: `[16|1], [2|15], [14|3]...`
- Ideal para: imprimir en fotocopiadora doble cara, doblar a la mitad y grapar

## Características que cumplen tu ejemplo

✅ **Portada:** "Extractos para Estudio:" + Título grande centrado + Logo opcional
✅ **Página 2:** En blanco (respiro profesional)
✅ **Encabezados americanos:**
   - Páginas pares: `4  Extractos para Estudio:` (número izquierda)
   - Páginas impares: `UNÁNIMES JUNTOS  5` (título izquierda, número derecha)
✅ **Márgenes estándar americano:**
   - Superior 0.75", Inferior 0.75"
   - Interior/Lomo 0.90" (para encuadernación)
   - Exterior 0.60"
   - Sangría primera línea 0.25", texto justificado, Times 10.5pt
✅ **Paginación espejo** (mirror margins)
✅ **Folleto automático** con páginas ordenadas para booklet

## Cómo usar

1. Abre la app (preview en puerto 5000)
2. Escribe el **Título del Libro** (ej: UNÁNIMES JUNTOS)
3. Sube tu **archivo Word**
4. (Opcional) Sube un **logo** para portada
5. (Opcional) Ajusta márgenes en "Avanzado"
6. Clic en **Generar Libros PDF**
7. Descarga los dos PDFs

## Instalación local

```bash
pip install -r requirements.txt
python app.py
# Abrir http://localhost:5000
```

## Tecnologías

- Flask + ReportLab (generación PDF profesional)
- python-docx (lectura Word)
- PyPDF2 (imposición folleto)
- Pillow (logos)

## Basado en tus ejemplos

Se analizó:
- `Dig.UNÁMIMES JUNTOS.pdf` → 16 págs, 5.51x8.51"
- `Foll.UNÁNIMES JUNTOS.pdf` → 8 págs físicas, 11x8.5", 2 lógicas por cara

Replicado 100% el estilo.
