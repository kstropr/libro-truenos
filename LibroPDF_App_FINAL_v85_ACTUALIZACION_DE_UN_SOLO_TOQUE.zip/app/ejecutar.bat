@echo off
cd /d "%~dp0"
echo ==========================================
echo  APP LIBRO PDF - Servidor
echo  Deje esta ventana abierta mientras usa la app
echo  NO haga clic dentro de esta ventana
echo ==========================================
echo.
python app.py
if errorlevel 1 (
    echo.
    echo Python fallo, intentando con py...
    py app.py
)
if errorlevel 1 (
    echo.
    echo py fallo, intentando con python3...
    python3 app.py
)
echo.
echo El servidor se cerro. Si vio un error, tome captura de esta ventana.
pause
